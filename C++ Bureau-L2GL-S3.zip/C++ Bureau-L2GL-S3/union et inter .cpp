#include <iostream>
using namespace std;

void remplitab(int t[],int n){
int i;
    for(i=0; i<n; i++){
        cout<<"["<<(i+1)<<"]:";
        cin>>t[i];
    }
}

void Affitab(int t[],int n){
int i;
    for(i=0; i<n; i++){
        cout<<t[i]<<" ";
    }
    cout<<endl;
}

int uniontableau(int T1[],int n1,int T2[],int n2,int T3[]){
int i,j,c=0,trouve;
for(i=0;i<n1;i++){
    trouve=0;
    for(j=0;j<c;j++){
        if(T1[i]=T3[j])
            trouve=1;
    }
    if(trouve==0){
        T3[c]=T1[i];
        c++;
    }
}

for(i=0;i<n2;i++){
    trouve=0;
    for(j=0;j<c;j++){
        if(T2[i]=T3[j])
            trouve=1;
    }
    if(trouve==0){
        T3[c]=T2[i];
        c++;
    }
}
return c;
}

int intertab(int T1[],int n1,int T2[],int n2,int T3[]){
    int i,j,trouve,k;
    for(i=0;i<n1;i++){
        trouve=0;
        for(j=0;<n2;j++){
            if(T1[i]=T2[j])
        }
    }
}
int main() {

int n1,n2;

do {
    cout<<"entrer la taille du tableau 1 :";
    cin n1;
}while(n1<=0);

do {
    cout<<"entrer la taille du tableau 2 :";
    cin n2;
}while(n2<=0);

int T1[n1],T2[n2],T3[n1+n2],texact=0;

remplitab(T1,n1);
remplitab(T2,n2);
cout<<"Affichage du tableau 2 ";
Affitab(T2,n2);
texact=uniontableau(T1[],n1,T2[],n2,T3);































    return 0;
}

