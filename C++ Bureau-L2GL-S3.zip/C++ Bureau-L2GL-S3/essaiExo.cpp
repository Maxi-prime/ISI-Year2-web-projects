#include <iostream>
#include"Chauffeur.h"
using namespace std;

struct Chauffeur{
char nom[10],prenom[20],cni[25];
float salaire;
};

struct listeb{
Chauffeur info;
listeb*prec;
listeb*suiv;
};

Chauffeur scanchauff(){
    Chauffeur c;
    cout<<"Prenom : ";
    cin>>c.prenom;
     cout<<"Nom : ";
    cin>>c.nom;
    cout<<"CNI : ";
    cin>>c.cni;
    cout<<"Salaire : ";
    cin>>c.salaire;
    return c;
}

void printchauff(scanchauff) {
    cout<<"Nom :",c->nom;
    cout<<"Prenom :",c->prenom;
    cout<<"CNI :",c->cni;
    cout<<"Salaire :",c->salaire;

}

int menu(){
int choix
do{
    count<<".......Faites votre choix........";
    cout<<"1-Ajouter chauffeur";
    cout<<"2-Lister les chauffeurs";
    cout<<"3-Supprimer un chauffeur a une position";
    cout<<"4-Afficher le chauffeur max";
    cout<<"5-Modifier un chauffeur ";
    cout<<"6-Quitter ";
    cin>>choix;
}while(choix<1 || choix>5);
}

int chx;
do{
    chx=menu();
}
int main() {
maxc,minc=c;

listeb*tete=nullptr;
listeb*k;
listeb*fin=nullptr;
char res[10];

do{
        k=new listeb;
        k->suiv=nullptr;
        k->prec=nullptr;
        k->info=scanchauff;

    cout<<"Voulez vous ajout� un autre chauffeur ?"<<endl;
}while(strasecmp(res,"oui")==0);

int choix;





if(i==1){
    maxc=c;
    minc=c;
} else {
    if(c.salaire>maxc){
        maxc=c;
    } else if(c.salire<minc){
        minc=c;
    }
}

if(choix==1){

}














    return 0;
}




