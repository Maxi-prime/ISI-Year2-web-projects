#include <iostream>
using namespace std;

int main() {

/**Exo: Remplire une matrice de L lignes et de C colonnes
-Trier le premiere colonne(Decroissant)
-Inverser la derniere colonne **/

int i,j,L;
    do{
        cout<<"Entrer le nombre de lignes: ";
        cin>>L;
    }while(L<=0);

int C;
    do{
        cout<<"Entrer le nombre de colonnes: ";
        cin>>C;
    }while(C<=0);

int** mat = new int*[L];

for(i=0 ; i<L ;i++ ){
  mat[i]=new int[C];
}

cout<<"Remplissage de la matrice :";
  for(i=0; i<L ;i++){
    for(j=0; j<C; j++){
        cout<<"["<<i+1<<"]"<<"["<<j+1<<"]";
        cin>>L,C;
        }
}

cout<<"Affichage de la matrice avant le tri et l'inversion ";
  for(i=0; i<=L ;i++){
    for(j=0; j<=C; j++){
        cout<<mat[i][j]<<" ";
        }
        cout<<endl;
}

int tmp=0;
cout<<"Tri decroissant de la premier colonne de la  matrice "<<endl;
   for(i=0; i<L ;i++){
         for(j=i+1; j<L ;j++){
            if(mat[i][0] < mat[j][0]){
                tmp=mat[i][0];
                mat[i][0]=mat[j][0];
                mat[j][0]=tmp;
            }
        }
    }

cout<<"Affichage de la matrice apr�s le tri de la matrice  ";
  for(i=0; i<L ;i++){
    for(j=0; j<C; j++){
        cout<<mat[i][j];
        }
        cout<<endl;
}

cout<<"Inversion de la derniere colonne "<<endl;
   for(i=0; i<L/2 ;i++){

        tmp=mat[i][C-1];
        mat[i][C-1]=mat[L-1-i][C-1];
        mat[L-1-i][C-1]=tmp;

        }
    }
 cout<<"Affichage de la matrice apr�s l'inverson  ";
  for(i=0; i<L ;i++){
    for(j=0; j<C; j++){
        cout<<mat[i][j];
        }
        cout<<endl;
}















for(i=0 ;i<L;i++ ){
 delete []=mat[i];
}
delete[] mat;



    return 0;
}


