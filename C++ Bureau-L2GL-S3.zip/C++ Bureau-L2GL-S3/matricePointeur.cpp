#include<iostream>
using namespace std;
int main(){
    int L,C;
    do{
        cout<<"Le nombre de ligne: ";
        cin>>L;
    }while(L<=0);
    do{
        cout<<"Le nombre de colonne: ";
        cin>>C;
    }while(C<=0);
    int** m = new int*[L];//etape 1 initialiser le nombre de ligne
    for(int i=0;i<L;i++){
        m[i]= new int[C];
    }
    cout<<"Remplissage de la matrice "<<endl;
    for(int i=0;i<L;i++){
        for(int j=0;j<C;j++){
            cout<<"["<<i<<"]["<<j<<"]: ";
            cin>>m[i][j];
        }
    }
    cout<<"Affichage de la matrice "<<endl;
    for(int i=0;i<L;i++){
        for(int j=0;j<C;j++){
            cout<<m[i][j]<< " ";
        }
        cout<<endl;
    }
    //liberation de la memoire
     for(int i=0;i<L;i++){
        delete[] m[i];
    }
    delete[] m;
    //int* tab = new int[5];
}
