#include <iostream>
using namespace std;

struct etudiant{
char nom[10],mat[10];
int age;
};

struct listeb{
etudiant info;
listeb*pre;
listeb*suiv;
};

etudiant scanetu(){
    etudiant e;
    cout<<"le nom: ";
    cin>>e.nom;
     cout<<"le matricule: ";
    cin>>e.mat;
    cout<<"L'age: ";
    cin>>e.age;
}
int main() {
listeb*tete=nullptr;
listeb*fin=nullptr;
listeb*k;
char res[10];

do{
        k=new listeb;
        k->suiv=nullptr;
        k->prec=nullptr;
        k->info=scanetu;

    cout<<"Voulez vous ajoutee un autre ?"<<endl;
}while(strasecmp(res,"oui")==0);





















    return 0;
}




