#include <iostream>
using namespace std;

void  Affichetableau(int*tab,int n){

   for(int i=0; i<n ;i++){
        cout<<tab[i]<<" ";
    }
}


void  Remplissagetableau(int*tab,int n){
 cout<<"Remplissage du tableau"<<endl;
    int i;
    for(i=0; i<n ;i++){

            cout<<"tab ["<<i+1<<"] :";
            cin>>tab[i];
    }

}

void  inversiontableau(int*tab,int n){
    int i,j;
    for(i=0,j=n-1; i<n/2 ;i++,j-- ){
       int tmp=tab[i];
        tab[i]=tab[j];
        tab[j]=tmp;
    }

}

void tri(int*tab,int n,char ord ){
       cout<<"Tri du tableau";

       for(i=0; i<n ;i++){
         for(j=i+1; j<n ;j++) {
            if(tab[i]>tab[j]){
                int tmp=tab[i];
                if(ord='c'){
                    if(tab[i]=tab[j]){
                        tab[i]=tab[j];
                        tab[j]=tmp;
                    }
                }else{
                 if(tab[i]<tab[j]){
                    tab[i]=tab[j];
                    tab[j]=tmp;
                 }
                }


            }
        }
     }
}

int main() {

int n;
    do{
        cout<<"Entrer le nombre de cellules: ";
        cin>>n;
    }while(n<=0);

int *tab=new int[n];

    Remplissagetableau(tab,n);

    cout<<"Affichage du tableau avant tri et inverson"<<endl;
    Affichetableau(tab,n);

    inversiontableau(tab,n);


    cout<<endl;
    cout<<"Affichage du tableau apres inverson"<<endl;
    Affichetableau(tab,n);
    cout<<endl;
    char ordre;


//     cout<<"Tri du tableau";
//       for(i=0; i<n ;i++){
//         for(j=i+1; j<n ;j++){
//            if(tab[i]>tab[j]){
//                tmp=tab[i];
//                tab[i]=tab[j];
//                tab[j]=tmp;
//            }
//        }
//    }
//
    do{
        cout<<"Choissisez l'ordre "<<endl;
        cout<<"d - pour decroissant "<<endl;
        cout<<"c - pour croissant "<<endl;
        cin>>ordre;
    }while(ord!='c'&& ord!='d');
    tri(tab,n,ordre);
    cout<<endl;
    cout<<"Affichage du tableau apres tri"<<endl;
    Affichetableau(tab,n);

//
//
//delete [] tab;







    return 0;
}


