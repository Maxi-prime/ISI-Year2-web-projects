#include <iostream>
using namespace std;

int main() {

int k=10;
int* kp=&k;
int** p=&kp;


cout<<"Valeur a travers k: "<<k <<endl;
cout<<"Valeur a travers kp: "<<*kp <<endl;
cout<<"Valeur a travers p: "<<**p <<endl;
cout<<"Adresse P: "<<&k <<endl;



delete kp;




















    return 0;
}


