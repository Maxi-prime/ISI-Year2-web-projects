#include<iostream>
#include<fstream>
#include<cstring>
#include"Commandes.h"

using namespace std;

int menuBienvenu(){
    int choix;

do{
        cout<<"==== BIENVENUE ====";
        cout<<"1- Se connecter"<<endl;
        cout<<"2- Quitter"<<endl;

        cout<<"Votre choix :"<<endl;
        cin>>choix;

        if(choix!=1 || choix!=2){
            cout<<"Veuillez choisir entre 1 ou 2 svp ";
        }
    }while(choix<1 || choix>2);

    return choix;
     }

     char choisir[8];
Uconnecte scanUtilisateurC(){
    Utilisateur u;
    int taille = 0;
    do{
    cout<<"ADMIN";
    cout<<"CLIENT";
    cout<<"CHOISIR UN ROLE";
    cin>>choisir;

    }while(strcasecmp(choisir,"ADMIN")!=0 && strcasecmp(choisir,"CLIENT")!=0 );

    if(choisir=="ADMIN"){
        do{
    cout<<"Mot de passe : ";
    cout<<"Le mot de passe doit avoir une lettre majiscule ,@ ou # ou $ et au total minimum 8 caracteres";
    cin>>umotdePasse;
    taille = strlen(u.motdePasse);
    }while(taille >= 8);

    cout<<"Email";
    cin>>u.email;
    if(u.email == "Magayesanembaye2001@gmail.com" && u.motdePasse == "Genielogiciel#"){
        cout
        cout<<"Bienvenue l'administrateur ";
        MenuAdmin();
    } else {
        cout<<"Erreur de connexion";
        menuBienvenu();
    }
    }else if(choisir=="CLIENT"){
        cout<<"Bienvenue a notre fidele client ";
        MenuClient();
    }else {
        cout<<"Erreur de connexion";
        menuBienvenu();
    }
}

int cptidUtilisatur=1;
Utilisateur scanUtilisateur(){
    Utilisateur u;

    int taille = 0;
    cptidUtilisatur++;
    cout<<"Nom : ";
    cin>>u.nom;
    cout<<"Prenom : ";
    cin>>u.prenom;

    cout<<"Email (UNIQUE) : ";
    cin>>u.email;

    do{
    cout<<"Mot de passe : ";
    cout<<"Le mot de passe doit avoir une lettre majiscule ,@ ou # ou $ et au total minimum 8 caracteres";
    cin>>u.motdePasse;
    taille = strlen(u.motdePasse);
    }while(taille >= 8);

     do{
    cout<<"Role : 'ADMIN'-'CLIENT' : ";
    cin>>u.role;
    }while(strcasecmp(u.role,"ADMIN")!=0 && strcasecmp(u.role,"CLIENT")!=0 );

    return u;
}

int cptidProduit=1;
Produit scanProduit(){
    Produit p;
    cptidProduit++;
    cout<<"Nom Produit : ";
    cin>>p.nomProduit;
    cout<<"Prix Produit : ";
    cin>>p.prix;
  do{
    cout<<"Quantit� Stock : ";
    cin>>p.Quantitestock;
    }while(p.Quantitestock<0);

    return p;
}

ProduitPanier scanProduitPanier(){
    ProduitPanier pa;
    cptidProduit++;
    cout<<"Nom Produit : ";
    cin>>pa.nomProduitP;
    cout<<"Prix Produit : ";
    cin>>pa.prixP;
  do{
    cout<<"Quantit� Stock : ";
    cin>>pa.QuantitestockP;
    }while(pa.QuantitestockP<0);

    return p;
}

int cptidCommande=1;
Commande scanCommande(){
 Commande c;
 cptidCommande++;
 cptidUtilisatur++;
 cout<<"La datte de la commande";
 cin>>c.DateCom;
}

int MenuAdmin(){
    int choix1;
do{
        cout<<"==== BIENVENUE AU MENU ADMIN ====";
        cout<<"1- Gestion des utilisateurs"<<endl;
        cout<<"2- Gestion des produits"<<endl;
        cout<<"3- Consulter toutes les commandes"<<endl;
        cout<<"4- D�connexion"<<endl;

        cout<<"Votre choix :"<<endl;
        cin>>choix1;

        if(choix1!=1 || choix1!=4){
            cout<<"Veuillez choisir entre 1 - 4 svp ";
        }
    }while(choix1<1 || choix1>4);

    return choix1;
     }

int MenuGestionUtilisateurs(){
    int choix2;
do{
        cout<<"==== GESTION UTILISATEUR ====";
        cout<<"1- Ajouter un utilisateur"<<endl;
        cout<<"2- Modifier un utilisateur"<<endl;
        cout<<"3- Supprimer un utilisateur"<<endl;
        cout<<"4- Lister les utilisateurs"<<endl;
        cout<<"5- Retour"<<endl;

        cout<<"Votre choix :"<<endl;
        cin>>choix2;

        if(choix2!=1 || choix2!=5){
            cout<<"Veuillez choisir entre 1 - 5 svp ";
        }
    }while(choix1<1 || choix1>5);

    return choix2;
     }

void ajouterUtilisateur(){
    ofstream fichier("utilisateur.dat",ios::binary | ios::app);
    if(!fichier){
        cout<<"Erreur d'ouverture du fichier";
        return;
    }
    Utilisateur u = scanUtilisateur();
    fichier.write((char*)&u,sizeof(Utilisateur));
    fichier.close();
}

void modifierUtilisateur(){
     ifstream fichier("utilisateur.dat",ios::binary);
     ofstream ftemp("tmp.dat", ios::binary | ios::app);
    if(!fichier){
        cout<<"Erreur d'ouverture du fichier";
        return;
    }
    Utilisateur u;

    while(fichier.read((char*)&u,sizeof(Utilisateur))){
        if(strcasecmp(u.prenom,"Magaye")!=0){
             ftemp.write((char*)&u,sizeof(Utilisateur));
        }else{
            cout<<"Le nouveau nom: ";
            cin>>u.nom;
            cout<<"Le nouveau Prenom: ";
            cin>>u.prenom;
            cout<<"Le nouveau Mail: ";
            cin>>u.email;
            int taille = 0;
            do{
                cout<<"Le nouveau mot de passe: ";
                cout<<"Le mot de passe doit avoir une lettre majiscule ,@ ou # ou $ et au total minimum 8 caracteres";
                cin>>u.motdePasse;
                taille = strlen(u.motdePasse);
            }while(taille >= 8);
            ftemp.write((char*)&u,sizeof(Utilisateur));
        }
    }
    fichier.close();
    ftemp.close();
    remove("utilisateur.dat");
    rename("tmp.dat","utilisateur.dat");
}

void supprimerUtilisateur(){
 ifstream fichier("utilisateur.dat",ios::binary);
     ofstream ftemp("tmp.dat", ios::binary | ios::app);
    if(!fichier){
        cout<<"Erreur d'ouverture du fichier";
        return;
    }
    Utilisateur u;

    while(fichier.read((char*)&u,sizeof(Utilisateur))){
        if(strcasecmp(u.prenom,"Magaye")!=0){
             ftemp.write((char*)&et,sizeof(Utilisateur));
        }
    }
    fichier.close();
    ftemp.close();
    remove("utilisateur.dat");
    rename("tmp.dat","utilisateur.dat");
}

void ListerUtilisatuer(){
ifstream fichier("utilisateur.dat",ios::binary);
    if(!fichier){
        cout<<"Erreur d'ouverture du fichier";
        return;
    }
    Utilisateur u;

    while(fichier.read((char*)&u,sizeof(Utilisateur))){
    cout<<"IdUtilisateur :"<<cptidUtilisatur;
    cout<<"Nom: Mbaye  ";
    cout<<"PreNom: Magaye  ";
    cout<<"Email:Magayesanembaye2001@gmail.com";
    cout<<"Role: ADMIN "<<endl;
    cout<<"IdUtilisateur :"<<cptidUtilisatur;
    cout<<"Nom:  "<<u.nom;
    cout<<"PreNom:  "<<u.prenom;
    cout<<"Email:  "<<u.email;
    cout<<"Role:  "<<u.role<<endl;
    }
    fichier.close();

}

int MenuGestionProduits(){
     int choix3;
do{
        cout<<"==== GESTION PRODUIT ====";
        cout<<"1- Ajouter un Produit"<<endl;
        cout<<"2- Modifier un Produit"<<endl;
        cout<<"3- Supprimer un Produit"<<endl;
        cout<<"4- Lister les Produit"<<endl;
        cout<<"5- Retour"<<endl;

        cout<<"Votre choix :"<<endl;
        cin>>choix3;

        if(choix3!=1 || choix3!=5){
            cout<<"Veuillez choisir entre 1 - 5 svp ";
        }
    }while(choix3<1 || choix3>5);

    return choix3;
}

void ajouterProduit(){
        ofstream fichier("Produit.dat",ios::binary | ios::app);
    if(!fichier){
        cout<<"Erreur d'ouverture du fichier";
        return;
    }
    Produit p = scanProduit();
    fichier.write((char*)&u,sizeof(Produit));
    fichier.close();
}

void modifierProduit(){
     ifstream fichier("Produit.dat",ios::binary);
     ofstream ftemp("tmp.dat", ios::binary | ios::app);
    if(!fichier){
        cout<<"Erreur d'ouverture du fichier";
        return;
    }
    Produit p;
    while(fichier.read((char*)&p,sizeof(Produit))){
        if(strcasecmp(p.nomProduit,"Lait")!=0){
             ftemp.write((char*)&p,sizeof(Produit));
        }else{
            cout<<"Le nouveau nom du produit: ";
            cin>>p.nomProduit;
            cout<<"Le nouveau Prix du produit: ";
            cin>>p.prix;
            cout<<"La nouvelle quantite: ";
            cin>>p.Quantitestock;
            int taille = 0;
            ftemp.write((char*)&p,sizeof(Produit));
        }
    }
    fichier.close();
    ftemp.close();
    remove("Produit.dat");
    rename("tmp.dat","Produit.dat");
}

void supprimerProduit(){
 ifstream fichier("Produit.dat",ios::binary);
     ofstream ftemp("tmp.dat", ios::binary | ios::app);
    if(!fichier){
        cout<<"Erreur d'ouverture du fichier";
        return;
    }
    Produit p;
    while(fichier.read((char*)&p,sizeof(Produit))){
        if(strcasecmp(p.nomProduit,"lait")!=0){
             ftemp.write((char*)&p,sizeof(Produit));
        }
    }
    fichier.close();
    ftemp.close();
    remove("Produit.dat");
    rename("tmp.dat","Produit.dat");
}

void ListerProduit(){
    if(!fichier){
        cout<<"Erreur d'ouverture du fichier";
        return;
    }
    Produit p;
    while(fichier.read((char*)&p,sizeof(Produit))){
    cout<<"IdProduit :"<<cptidProduit;
    cout<<"NomProduit:  "<<p.nomProduit;
    cout<<"Prix Produit:  "<<p.prix;
    cout<<"Quantite en stock  "<<p.Quantitestock<<endl;
    }
    fichier.close();
}

void ajouterCommande(){
     ofstream fichier("commande.dat",ios::binary | ios::app);
    if(!fichier){
        cout<<"Erreur d'ouverture du fichier";
        return;
    }
    Commande c= scanCommande();
    fichier.write((char*)&c,sizeof(Produit));
    fichier.close();
}

void affichercommande(){
        if(!fichier){
        cout<<"Erreur d'ouverture du fichier";
        return;
    }
    Produit p;
    while(fichier.read((char*)&c,sizeof(Commande))){
    cout<<"IdCommande :"<<cptidCommande;
    cout<<"Idutilisateur :"<<cptidUtilisatur;
    cout<<"Date de la commande:  "<<c.date;
    cout<<"Quantite en stock  "<<p.Quantitestock<<endl;
    }
    fichier.close();
}

int MenuClient(){
int cl1;
do{
        cout<<"==== BIENVENUE A NOTRE CLIENT MENU====";
        cout<<"1- Consulter les produits "<<endl;
        cout<<"2- Gerer panier"<<endl;
        cout<<"3- Valider la commande "<<endl;
        cout<<"4- Consultater mes commandes"<<endl;
        cout<<"5- Deconnexion"<<endl;

        cout<<"Votre choix :"<<endl;
        cin>>cl1;

        if(cl1!=1 || cl1!=5){
            cout<<"Veuillez choisir entre 1 - 5 svp ";
        }
    }while(choix1<1 || choix1>5);

    return cl1;
}

int menuGererPanier(){
int cl2;
do{
        cout<<"==== MENU GESTION DES PANIERS====";
        cout<<"1- Ajouter un produit au panier "<<endl;
        cout<<"2- Modifier la quantite"<<endl;
        cout<<"3- Supprimer un produit du panier "<<endl;
        cout<<"4- Afficher le panier "<<endl;
        cout<<"5- Vider le panier"<<endl;
        cout<<"6- Retour"<<endl;

        cout<<"Votre choix :"<<endl;
        cin>>cl2;

        if(cl2!=1 || cl2!=6){
            cout<<"Veuillez choisir entre 1 - 6 svp ";
        }
    }while(cl2<1 || cl2>6);

    return cl2;
}

void affichePanier(listeMono* tete){
    listeMono* p=tete;
    while(p!=nullptr){
        cout<<p->info<<endl;
        p=p->suiv;
    }
    delete p;
}

void listebi*supprimerProduit(listebi* tete,char c[]){
    listebi* pc;
    pc=tete;
    listebi* k;
    while(pc!=nullptr){
    if(strcasecmp(pc->info.nomProduit,c)==0){
            if(pc->prec==nullptr){
                tete=pc->suiv;
                delete pc;
                return tete;
            }else{
             k=pc;
             pc=pc->prec;
             pc->suiv=k->suiv;
             if(k->suiv!=nullptr)
             k->suiv->prec=pc;
            }
        }
        pc=pc->suiv;
    }
    delete k;
    return tete;
}

void ajouterlignescommande(){
    ofstream fichier("lignescommande.dat",ios::binary | ios::app);
    if(!fichier){
        cout<<"Erreur d'ouverture du fichier";
        return;
    }
    LigneCommande l = scanlignescommande();
    fichier.write((char*)&u,sizeof(LigneCommande));
    fichier.close();
}








































