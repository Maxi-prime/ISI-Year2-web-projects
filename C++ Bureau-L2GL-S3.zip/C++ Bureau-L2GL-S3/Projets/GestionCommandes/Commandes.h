#ifndef COMMANDES_H_INCLUDED
#define COMMANDES_H_INCLUDED

struct Utilisateur{
    int idUtilisateur;
    char nom[10],prenom[20],email[25],motdePasse[30],role[6];
};

struct Uconnecte{
    char email[25],motdePasse[30],codesecret[7];
};

struct listeMono{
    int info;
    listeMono* suiv;
};
struct Produit{
    int idProduit,Quantitestock;
    char nomProduit[20];
    float prix;
};
struct listebi{
    Produit info;
    listebi* prec;
    listebi* suiv;
};



struct ProduitPanier{
    int idProduit,QuantitestockP;
    char nomProduitP[20];
    float prixP;
};

struct Commande{
    int idCommande,idUtilisateur,DateCom;
    float montantTotal;
};

struct LigneCommande{
    int idCommande,idProduit,Quantite;
    float prixUnitaire;
};

void ajouterUtilisateur();
void modifierUtilisateur();
void supprimerUtilisateur();
void ListerUtilisatuer();
void ajouterProduit();
void modifierProduit();
void supprimerProduit();
void ListerProduit();
void ListeCommande();
void afficheListe(listeMono* tete);
void listebi*supprimerProduit(listebi* tete,char c[]);







#endif // COMMANDES_H_INCLUDED
