#include <iostream>
#include"Commandes.h"
using namespace std;

int main()
{
    int choix,choix1;

do{
    choix = menuBienvenu();
    system("cls");

  switch(chx){
    case 1:
        scanUtilisateurC();
        system("pause");
        break;
    case 2:
        cout<<"-----Aurevoir Bonne Journ�e------";
        break;
        }
    }while(chx!=2);

do{
    choix1 = MenuAdmin();
    system("cls");
 switch(choix1){
    case 1:
        MenuGestionUtilisateurs();
        system("pause");
        if(choix2 == 1){
            ajouterUtilisateur();
            system("pause");
        } else if (choix2 == 2){
            modifierUtilisateur();
            system("pause");
        }else if (choix2 == 3){
            supprimerUtilisateur();
            system("pause");
        }else if (choix2 == 4){
            ListerUtilisatuer();
            system("pause");
        }else if (choix2 == 5){
             MenuAdmin();
             system("cls");
        }
        break;
    case 2:
        MenuGestionProduits();
        system("pause");
        if(choix3 == 1){
            ajouterProduit();
            system("pause");
        } else if (choix3 == 2){
            modifierProduit();
            system("pause");
        }else if (choix3 == 3){
            supprimerProduit();
            system("pause");
        }else if (choix3 == 4){
            ListerProduit();
            system("pause");
        }else if (choix3 == 5){
             MenuAdmin();
             system("cls");
        }
        break;
    case 3:
        affichercommande();
        system("pause");
        }
    case 4:
    MenuAdmin();
    system("cls");
}while(chx!=4)

do{
    cl1 = MenuClient();
    system("cls");

  switch(cl1){
    case 1:
        cout<<"Les produits disponibles:";
        ListerProduit();
        system("pause");
        break;
    case 2:
        cout<<"Ajout d'un Produit au Panier"<<endl;
        k=new listebi;
        k->info=scanProduitPanier();
        k->prec=nullptr;
        k->suiv=nullptr;

        if(tete==nullptr){
        tete=k;
            }else{
                fin->suiv=k;
                k->prec=fin;
        }
        fin=k;
        system("Pause");
        break;
        }
    case 3:
        char c[20];
        cout<<"Quel est le nom du  Produit voulez vous supprimer";
        cin>>c;
        tete = supprimerPos(tete,matri);
        system("pause");
        break;
     case 4:
        afficheListe(listeMono* tete);
        system("pause");
        break;
     case 5:
         delete tete;
        system("pause");
        break;
      case 6:
        MenuClient();
        system("pause");
        break;
    }while(chx!=6);















    return 0;
}
