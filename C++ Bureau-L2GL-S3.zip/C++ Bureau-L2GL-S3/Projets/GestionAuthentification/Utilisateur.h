#ifndef UTILISATEUR_H_INCLUDED
#define UTILISATEUR_H_INCLUDED

struct Utilisateur{
    char nom[20],prenom[20],matricule[20],email[40],role[13];
    float salaire;
};
struct listeMono{
    int info;
    listeMono* suiv;
};

struct listebi{
    Utilisateur info;
    listebi* prec;
    listebi* suiv;
};
int menuPrincipale();
int menuAccueil();
Utilisateur scanutilisateur();
void printAllUtilisateur(listebi* tete);
void printUtilisateur(Utilisateur u);
listebi*supprimerPos(listebi* tete,char matri[]);
void tri(int*tab,int n,float salaire);
void afficheListe(listeMono* tete);
void profResponsable();
void profplusA();








#endif // UTILISATEUR_H_INCLUDED
