#include <iostream>
#include"Utilisateur.h"
using namespace std;

int main()
{
    int c;
    char matri[25];
    float tmp;
    listebi* tete=nullptr;
    listebi* fin=nullptr;
    listebi* k;
do{
    c = menuPrincipale();
    system("cls");

    switch(c){
        case 1:
            cout<<"Ajouter un Professeur"<<endl;
    k=new listebi;
    k->info=scanutilisateur();
    k->prec=nullptr;
    k->suiv=nullptr;

    if(tete==nullptr){
        tete=k;
    }else{
        fin->suiv=k;
        k->prec=fin;
        }
    fin=k;
    system("Pause");
    break;

        case 2:
    cout<<"Afficher les Profs"<<endl;
    printAllUtilisateur(tete);
    system("Pause");
    break;
        case 3:
    cout<<"Trier la liste dans l'ordre decroisant"<<endl;
    cout<<"Affichage du tableau apres inverson"<<endl;


    system("Pause");
    break;
        case 4:
    cout<<"Transferer dans une liste mono les profs dont salaire < a la moyenne "<<endl;
     //afficheListe(listeMono* tete);
    system("Pause");
    break;
        case 5:
    cout<<"Afficher le prof dont le nom compte plus de lettre 'a' "<<endl;
    system("Pause");
    break;

        case 6:
    cout<<"Vous allez supprimer un prof suivant son matricule"<<endl;
    cout<<"Entrer le matricule du prof svp: ";
    cin>>matri;
    tete = supprimerPos(tete,matri);

        case 7:
    cout<<"Transferer les profs dont role = responsable dans une matrice"<<endl;
       int L,C;
     do{
        cout<<"Le nombre de ligne: ";
        cin>>L;
      }while(L<=0);
     do{
        cout<<"Le nombre de colonne: ";
        cin>>C;
     }while(C<=0);

    cout<<"Remplissage de la matrice :";

    system("Pause");
    break;
        case 8:
    cout<<"Afficher liste mono"<<endl;
    system("Pause");
    break;
       case 9:
    cout<<"Afficher Matrice"<<endl;
    system("Pause");
    break;
       case 10:
    cout<<"---Quitter"<<endl;
    system("Pause");
    break;
    }


}while(c!=10);

delete tete;
delete fin;
delete k;

    return 0;
}
