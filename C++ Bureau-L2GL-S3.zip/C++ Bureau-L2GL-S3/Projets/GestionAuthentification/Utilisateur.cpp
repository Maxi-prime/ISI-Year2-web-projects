#include<iostream>
#include"Utilisateur.h"
#include<cstring>
using namespace std;

int menuPrincipale(){
    int choix;
    do{
   cout<<"--- Faites votre choix s'il vous plait : --- "<<endl;
    cout<<"1- Ajouter un Professeur(Eviter les doublons de matricules svp)"<<endl;
    cout<<"2- Afficher les Profs"<<endl;
    cout<<"3- Trier la liste dans l'ordre decroissant"<<endl;
    cout<<"4- Transferer dans une liste mono les profs dont salaire < a la moyenne "<<endl;
    cout<<"5- Afficher le prof dont le nom compte plus de lettre 'a'"<<endl;
    cout<<"6- Supprimer un prof(Suivant matricule)"<<endl;
    cout<<"7- Transferer les profs dont role=responsable dans une matrice"<<endl;
    cout<<"8- Afficher liste mono "<<endl;
    cout<<"9- Afficher Matrice "<<endl;
    cout<<"10 --- Quitter--- "<<endl;

    cin>>choix;

    }while(choix<1 || choix >10);

    return choix;
}

Utilisateur scanutilisateur(){

    Utilisateur u;
    int cpt;
    float moy,som=0;

    cout<<"Nom : ";
    cin>>u.nom;
    cout<<"Prenom :  ";
    cin>>u.prenom;
    cout<<"Matricule personnel(Unique) :  ";
    cin>>u.matricule;
    cout<<"Salaire : ";
    cin>>u.salaire;
    som=som+u.salaire;
    cpt=cpt+1;
    cout<<"Email : ";
    cin>>u.email;

    do{
    cout<<"Role : 'RESPONSABLE'-'VOCATAIRE'  : ";
    cin>>u.role;
    }while(strcasecmp(u.role,"RESPONSABLE")!=0 && strcasecmp(u.role,"VOCATAIRE")!=0 );

    return u;
}

void printUtilisateur(Utilisateur u){
    cout<<"Prenom : "<<u.prenom<<endl;
    cout<<"Nom : "<<u.nom<<endl;
    cout<<"Matricule : "<<u.matricule<<endl;
    cout<<"Salaire : "<<u.salaire<<endl;
    cout<<"Email : "<<u.email<<endl;
    cout<<"Role : "<<u.role<<endl;
}

void printAllUtilisateur(listebi* tete){
    listebi* pc=tete;
    while(pc!=nullptr){
        printUtilisateur(pc->info);
        pc=pc->suiv;
    }
}


listebi* supprimerPos(listebi* tete,char matri[]){
    listebi* pc;
    pc=tete;
    listebi* k;
    while(pc!=nullptr){
    if(strcasecmp(pc->info.matricule,matri)==0){
            if(pc->prec==nullptr){
                tete=pc->suiv;
                delete pc;
                return tete;
            }else{
             k=pc;
             pc=pc->prec;
             pc->suiv=k->suiv;
             if(k->suiv!=nullptr)
             k->suiv->prec=pc;
            }
        }
        pc=pc->suiv;
    }
    delete k;
    return tete;
}

void afficheListe(listeMono* tete){
    listeMono* p=tete;
    while(p!=nullptr){
        cout<<p->info<<endl;
        p=p->suiv;
    }
    delete p;
}
void RemplissageMatrice(listebi* tete){
    cout<<"Remplissage de la matrice "<<endl;
}

