#ifndef ETUDIANT_H_INCLUDED
#define ETUDIANT_H_INCLUDED


struct Etudiant{
    char nom[10],mat[10];
    int age;
};
struct listeB{
    Etudiant info;
    listeB* prec;
    listeB* suiv;
};
Etudiant scanEtudiant();
void printEtudiant(Etudiant e);
void GDEtudiant(listeB* tete);

#endif // ETUDIANT_H_INCLUDED
