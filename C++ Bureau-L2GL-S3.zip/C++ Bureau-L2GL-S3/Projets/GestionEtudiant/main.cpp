#include <iostream>
#include"Etudiant.h"
#include<cstring>

using namespace std;

int main()
{


    char res[10];
    listeB* tete=nullptr;
    listeB* fin=nullptr;
    listeB* k;
    do{
        k=new listeB;
        k->prec=nullptr;
        k->suiv=nullptr;
        k->info=scanEtudiant();
        if(tete==nullptr){
            tete=k;
            fin=k;
        }else{
        fin->suiv=k;
        k->prec=fin;
        }
        cout<<"Voulez vous ajouter un autre etudiant?"<<endl;
        cin>>res;
    }while(strcasecmp(res,"oui")==0);
    GDEtudiant(tete);













    return 0;
}
