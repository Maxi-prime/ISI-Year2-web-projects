#include<iostream>
#include"fstream"
#include"CoursFichier.h"
using namespace std;
Etudiant ScanEtudiant(){
    Etudiant et;
    cout << "Nom: ";
    cin >> et.nom;
    cout << "Prenom: ";
    cin >> et.prenom;
    cout << "Age: ";
    cin >> et.age;
    return et;
}
void addFtext(){
    ofstream Fichier("Contenu.txt", ios::app);//ouverture
    if(!Fichier){
        cout << "Erreur d ouverture";//verification
        return;
    }
    Etudiant et = ScanEtudiant();
    Fichier << et.nom <<" " << et.prenom <<" "<<et.age <<endl;
    Fichier.close();
}
void AfficheFTexte(){
    ifstream Fichier("Contenu.txt");//Lecture
    if(!Fichier){
        cout << "Erreur d ouverture";//verification
        return;
    }
    Etudiant et;
    while(Fichier>>et.nom>>et.prenom>>et.age){//lecture de tous les donn�es du fichier
        cout << "Nom: " << et.nom <<" ";
        cout << "Prenom: " << et.prenom <<" ";
        cout << "Age: " << et.age << endl;
    }
    Fichier.close();
}
