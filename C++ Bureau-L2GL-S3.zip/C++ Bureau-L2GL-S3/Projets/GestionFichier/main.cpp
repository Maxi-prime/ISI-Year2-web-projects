#include <iostream>
#include"Fichier.h"
using namespace std;

int main()
{


    //addFtext();
    //AfficheFTexte();
    //addFbin();
    //supprimerFbin();
    //afficheFbin();
    //supprimerFtext();
    modifierFbin();
    afficheFbin();




    return 0;
}
