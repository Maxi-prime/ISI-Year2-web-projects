#ifndef FICHIER_H_INCLUDED
#define FICHIER_H_INCLUDED

struct Etudiant{
    char nom[20],prenom[20];
    int age;
};

Etudiant ScanEtudiant();

void addFtext();
void AfficheFTexte();

void addFbin();
void afficheFbin();

void supprimerFtext();
void supprimerFbin();

void modifierFbin();

int menu();
void addFin();
void AfficheFin();


#endif // FICHIER_H_INCLUDED
