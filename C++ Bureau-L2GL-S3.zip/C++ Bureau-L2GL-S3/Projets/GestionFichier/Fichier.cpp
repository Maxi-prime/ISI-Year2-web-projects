#include<iostream>
#include<fstream>
#include<cstring>
#include"Fichier.h"
using namespace std;

Etudiant ScanEtudiant(){
    Etudiant et;
    cout<< "Nom: ";
    cin>> et.nom;
    cout<< "Prenom: ";
    cin>> et.prenom;
    cout<< "Age: ";
    cin>> et.age;
    return et;
}
void addFtext(){
    ofstream Fichier("Contenu.txt", ios::app);//ouverture
    if(!Fichier){
        cout << "Erreur d ouverture";//verification
        return;
    }
    Etudiant et = ScanEtudiant();
    Fichier << et.nom <<" " << et.prenom <<" "<<et.age <<endl;
    Fichier.close();
}

void AfficheFTexte(){
    ifstream Fichier("Contenu.txt");//Lecture
    if(!Fichier){
        cout << "Erreur d ouverture";//verification
        return;
    }
    Etudiant et;
    while(Fichier>>et.nom>>et.prenom>>et.age){//lecture de tous les donn�es du fichier
        cout << "Nom: " << et.nom <<" ";
        cout << "Prenom: " << et.prenom <<" ";
        cout << "Age: " << et.age << endl;
    }
    Fichier.close();
}

//BINAIRE

void addFbin(){
    ofstream fichier("exo.dat",ios::binary | ios::app);
    if(!fichier){
        cout<<"Erreur d'ouverture";
        return;
    }
    Etudiant et = ScanEtudiant();

    fichier.write((char*)&et,sizeof(Etudiant));
    fichier.close();
}

void afficheFbin(){
    ifstream fichier("exo.dat",ios::binary);
    if(!fichier){
        cout<<"Erreur d'ouverture";
        return;
    }
    Etudiant et;

    while(fichier.read((char*)&et,sizeof(Etudiant))){
    cout<<"Nom:  "<<et.nom;
    cout<<"PreNom:  "<<et.prenom;
    cout<<"Age:  "<<et.age<<endl;
    }
    fichier.close();

}

//Suppression
void supprimerFtext(){
    ifstream fichier("Contenu.txt");//Lecture
    ofstream ftemp("temp.txt",ios::app);
    if(!fichier){
        cout<<"Erreur d'ouverture";
        return;
    }
    Etudiant et;
    while(fichier>>et.nom>>et.prenom>>et.age){
        if(et.age!=21){
             ftemp<< et.nom<<" " <<et.prenom <<" "<<et.age <<endl;
        }
    }
    fichier.close();
    ftemp.close();
    remove("Contenu.txt");
    rename("temp.txt","Contenu.txt");
}

void supprimerFbin(){
     ifstream fichier("exo.dat",ios::binary);
     ofstream ftemp("tmp.dat", ios::binary | ios::app);
    if(!fichier){
        cout<<"Erreur d'ouverture";
        return;
    }
    Etudiant et;

    while(fichier.read((char*)&et,sizeof(Etudiant))){
        if(strcasecmp(et.prenom,"fama")!=0){
             ftemp.write((char*)&et,sizeof(Etudiant));
        }
    }
    fichier.close();
    ftemp.close();
    remove("exo.dat");
    rename("tmp.dat","exo.dat");
}


//Modifier
void modifierFbin(){
     ifstream fichier("exo.dat",ios::binary);
     ofstream ftemp("tmp.dat", ios::binary | ios::app);
    if(!fichier){
        cout<<"Erreur d'ouverture";
        return;
    }
    Etudiant et;

    while(fichier.read((char*)&et,sizeof(Etudiant))){
        if(strcasecmp(et.prenom,"Ousmane")!=0){
             ftemp.write((char*)&et,sizeof(Etudiant));
        }else{ //les nouvelles informations a ajouter
            cout<<"Le nouveau nom: ";
            cin>>et.nom;
            ftemp.write((char*)&et,sizeof(Etudiant));
        }
    }
    fichier.close();
    ftemp.close();
    remove("exo.dat");
    rename("tmp.dat","exo.dat");
}


