#include<iostream>
#include"Chauffeur.h"
using namespace std;

int menu(){
    int choix;

    do{
        cout<<"1-Ajout Chauffeur"<<endl;
        cout<<"2-Lister Chauffeur"<<endl;
        cout<<"3-Supprimer Chauffeur"<<endl;
        cout<<"4-Afficher Chauffeur max"<<endl;
        cout<<"5-Modifier Chauffeur"<<endl;
        cout<<"6-Quittter"<<endl;
        cout<<"-----Votre choix-----"<<endl;
        cin>>choix;
    }while(choix<1 || choix>6);

    return choix;
     }


Chauffeur scanchauffeur(){
    Chauffeur ch;
    cout<<"Prenom : ";
    cin>>ch.prenom;
    cout<<"Nom : ";
    cin>>ch.nom;
    cout<<"CNI : ";
    cin>>ch.cni;
    cout<<"Salaire : ";
    cin>>ch.salaire;
    return ch;
}


void afficheliste(listeb*tete){
    listeb* pc=tete;
    while(pc!=nullptr){
        cout<<"CNI: "<<pc->info.cni;
        cout<<"Nom: "<<pc->info.nom;
        cout<<"Prenom: "<<pc->info.prenom;
        pc=pc->suiv;
    }
}

void suppchauff(listeb*tete){
     int sup;
    if(info.cni==sup){
        delete info.cni;
    }
}


void chauffmax(int i,scanchauffeur){
    int maxc;
if(i==1){
    maxc=ch;
}else{
if(maxc>ch.salaire){
    maxc=ch;
  }
 }
}
 void modchauff(){
     int mod;
 }
