#ifndef CHAUFFEUR_H_INCLUDED
#define CHAUFFEUR_H_INCLUDED

struct Chauffeur{
char nom[10],prenom[20],cni[25];
float salaire;
};

struct listeb{
Chauffeur info;
listeb*prec;
listeb*suiv;
};

Chauffeur scanchauffeur();

void afficheliste(listeb*tete);

void suppchauff();

void chauffmax();

void modchauff();

int menu();

#endif // CHAUFFEUR_H_INCLUDED
