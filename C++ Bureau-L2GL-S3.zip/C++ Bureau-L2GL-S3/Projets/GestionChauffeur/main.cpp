#include <iostream>
#include"Chauffeur.h"
using namespace std;

int main()
{
    int chx;
    listeb*tete=nullptr;
    listeb*k;
    listeb*fin=nullptr;

    do{
        chx = menu();
        system("cls");

        switch(chx){
    case 1:
        k=new listeb;
        k->prec=nullptr;
        k->suiv=nullptr;
        k->info = scanchauffeur();
        if(tete==nullptr){
            tete=k;
        }else{
        fin->suiv=k;
        k->prec=fin;
        }
        fin=k;
        break;
    case 2:
        afficheliste(tete);
        system("pause");
        break;
    case 3:
        cout<<"Saisir le CNI du chauffeur a supprimer";
        cin>>sup;
        suppchauff(sup);
        break;
    case 4:
        cout<<"Le chauffer max est:",maxc.nom,maxc.prenom,maxc.salaire;
        break;
    case 5:
        cout<<"Saisir le CNI du chauffeur � Modifier";
        cin>>mod;
        modchauff(mod);
        break;
    case 6:
        cout<<"-----Aurevoir------";
        break;

        }
    }while(chx!=6);



    return 0;
}
