#ifndef ELECTION_H_INCLUDED
#define ELECTION_H_INCLUDED

class Personne{
public:
    Personne(string n,string p,int a){
    nom=n;
    prenom=p;
    Nci=n;
    Nid=i;
    }
    void setPrenom(string p)(prenom=p);
    void setNom(string n)(nom=n);
    void setNci(int n)(Nci=n);
    void setNid(int i)(Nid=i);
    string getNom()(return nom);
    string getPrenom()(return prenom);
    int getNci()(return Nci);
};
class Candidat{
    nomParti=np;
    nbrvoix=p;
    Num�ro=nu;
    Nid=i;
};

class Electeur{
};


void remplirTabPartie(int t[],int n){
    int i,n=4;
    for(i=0; i<n; i++){
        cout<<"[APR] ";
        cout<<"[REWMI] ";
        cout<<"[PASTEF] ";
        cout<<"[PUR] ";
        cin>>t[i];
        }
          cout<<endl;
    }

void remplirTabZone(int t[],int n){
    int j,n=3;
    for(j=0; j<n; j++){
        cout<<"[Dakar] ";
        cout<<"[Thies] ";
        cout<<"[Touba] ";
        cin>>t[j];
        }
          cout<<endl;
    }
int menuPrincipale();
Personne scanPersonne();
//Candidat ();
//Electeur ();
#endif // ELECTION_H_INCLUDED
