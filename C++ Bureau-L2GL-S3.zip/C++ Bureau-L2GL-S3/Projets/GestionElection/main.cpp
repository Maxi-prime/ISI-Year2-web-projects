#include <iostream>

using namespace std;

int main()
{

    listebi* tete=nullptr;
    listebi* fin=nullptr;
    listebi* k;
do{
    c = menuPrincipale();
    system("cls");

    switch(c){
        case 1:
            cout<<"Ajouter un candidat"<<endl;
    k=new listebi;
    k->info=scanutilisateur();
    k->prec=nullptr;
    k->suiv=nullptr;

    if(tete==nullptr){
        tete=k;
    }else{
        fin->suiv=k;
        k->prec=fin;
        }
    fin=k;
    system("Pause");
    break;

        case 2:
    cout<<"Afficher les Profs"<<endl;
    printAllUtilisateur(tete);
    system("Pause");
    break;
        case 3:
    cout<<"Trier la liste dans l'ordre decroisant"<<endl;
    cout<<"Affichage du tableau apres inverson"<<endl;


    system("Pause");
    break;
        case 4:
    cout<<"Transferer dans une liste mono les profs dont salaire < a la moyenne "<<endl;
     //afficheListe(listeMono* tete);
    system("Pause");
    break;
        case 5:
    cout<<"Afficher le prof dont le nom compte plus de lettre 'a' "<<endl;
    system("Pause");
    break;























    return 0;
}
