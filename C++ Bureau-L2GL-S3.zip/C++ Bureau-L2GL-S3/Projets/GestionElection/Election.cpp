#include<iostream>
#include"Election.h"
#include<cstring>
using namespace std;

int menuPrincipale(){
    int choix;
    do{
    cout<<"--- Faites votre choix s'il vous plait : --- "<<endl;
    cout<<"1- Ajouter d'un candidat"<<endl;
    cout<<"2- Ajouter d'un electeur"<<endl;
    cout<<"3- Fiare le vote"<<endl;
    cout<<"4- R�sultat par ordre croissant"<<endl;
    cout<<"5 --- Quitter --- "<<endl;

    cin>>choix;

    }while(choix<1 || choix >5);

    return choix;
}

 Personne p;

    cout<<"Nom : ";
    cin>>p.getNom;
//    cout<<"Prenom :  ";
//    cin>>p.getPrenom;
//    cout<<"Num�ro d'identit� national :  ";
//    cin>>p.setNci;
//    cout<<"id : ";
//    cin>>p.setNid;
