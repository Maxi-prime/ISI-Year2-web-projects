#ifndef EMPLOYE_H_INCLUDED
#define EMPLOYE_H_INCLUDED

struct Employe{
    int id;
    char nom[20],prenom[20],service[20];
};

struct listeMono{
    Employe info;
    listeMono* suiv;
};

struct listeB{
    Employe info;
    listeB* prec;
    listeB* suiv;
};
void afficheListemono(listeMono* tete);
void afficheListeB(listeB* tete);
void printEmploye(Employe e);
Employe scanEmploye();
listeB* addDebut(listeB* tete);
listeB* addFin(listeB* tete);

void afficheListeBDG(listeB* fin);
void monoPos(listeMono* tete,int pos);
void biPos(listeB* tete,int pos);

//Transfere d1 employe dont le service est egal a maintenance
listeMono* transfert(listeB* tete);

#endif // EMPLOYE_H_INCLUDED
