#include <iostream>
#include"Employe.h"
using namespace std;

int main()
{

    char res;
    int choix;
//    listeMono* tete=nullptr;
//    listeMono* pc;
//    listeMono* k;
    listeB* tete=nullptr;
    listeB* fin;
    listeB* k;

    do{
//            k = new listeMono;
//            k->suiv=nullptr;
//            k->info=scanEmploye();
            k = new listeB;
            k->prec=nullptr;
            k->suiv=nullptr;
            k->info=scanEmploye();
            if(tete==nullptr){
                tete=k;
            }else{
//            pc->suiv=k;
            fin->suiv=k;
            k->prec=fin;
            }
//            pc=k;
            fin=k;
    cout<<"Voulez vous ajouter un autre employ� ?";
    cin>>res;
    }while(res=='O' || res=='o');


    //  afficheListemono(tete);
        afficheListeB(tete);
        cout<<"Ajout au debut: "<<endl;
        tete= addDebut(tete);
        //AJOUTER AU DEBUT de l'information
//        k = new listeB;
//        k->info=scanEmploye();
//        k->prec=nullptr;
//        k->suiv=tete;
//        tete->prec=k;
//        tete=k;
        cout<<"Affichage apres ajout au debut"<<endl;
        afficheListeB(tete);

             //AJOUTER A LA fin de l'information
             afficheListeBDG(fin);
            cout<<"Ajout a la fin: "<<endl;
            fin= addFin(fin);
            cout<<"Affichage apres ajout a la fin"<<endl;
            afficheListeBDG(fin);


            //Ajout a une position Liste mono
            //afficheListemono(tete);
//            cout<<"Ajoute a la position 2"<<endl;
//            monoPos(tete,2);
//            cout<<"Affichage apres ajout : "<<endl;
//            afficheListemono(tete);


            cout<<"Creer Employe";
            cout<<"Afficher Employe";
            cout<<"Ajout en debut";
            cout<<"Ajout en fin";
            cout<<"Ajout a une position";
            cout<<"Transfert";
            cout<<"Supprimer en debut";
            cout<<"Supprimer en fin";
            cout<<"Supprimer a une position";
            cout<<"Quitter";
            cout<<"Faites votre choix";
            cin>>choix;












    return 0;
}
