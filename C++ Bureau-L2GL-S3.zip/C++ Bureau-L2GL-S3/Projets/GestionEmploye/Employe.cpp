#include<iostream>
#include"Employe.h"
#include<cstring>
using namespace std;

void printEmploye(Employe e){
cout<<"Nom: "<<e.nom<<" Service: "<<e.service<<" Prenom: "<<e.prenom<<" ID: "<<e.id<<endl;
}
void afficheListemono(listeMono* tete){
    listeMono* pc=tete;
    while(pc!=nullptr){
    printEmploye(pc->info);
    pc=pc->suiv;
    }
}
void afficheListeB(listeB* tete){
    listeB* pc=tete;
    while(pc!=nullptr){
        printEmploye(pc->info);
        pc=pc->suiv;
    }
}

Employe scanEmploye(){
    Employe e;
    cout<<"Le Nom: ";
    cin>>e.nom;
    cout<<"Le PreNom: ";
    cin>>e.prenom;
    cout<<"Le ID: ";
    cin>>e.id;


    do{
    cout<<"Le Service(RH , MAINTENANCE , INFORMATIQUE ): ";
    cin>>e.service;
    }while(strcasecmp(e.service,"RH")!=0 && strcasecmp(e.service,"MAINTENANCE")!=0 && strcasecmp(e.service,"INFORMATIQUE")!=0 );


    return e;


}

listeB* addDebut(listeB* tete){
    listeB* k;
    k=new listeB;
    k->info=scanEmploye();
    k->prec=nullptr;
    k->suiv=nullptr;
    if(tete==nullptr){
        tete=k;
    }else{
    tete->prec=k;
    k->suiv=tete;
    tete=k;
    }
    return tete;
    }
listeB* addFin(listeB* fin){
    listeB* k;
    k=new listeB;
    k->info=scanEmploye();
    k->prec=nullptr;
    k->suiv=nullptr;
    if(fin!=nullptr){
     fin->suiv=k;
     k->prec=fin;
//     fin=k;
    }
     fin=k;
     return fin;
}

void afficheListeBDG(listeB* fin){
    listeB* pc=fin;
    while(pc!=nullptr){
        printEmploye(pc->info);
        pc=pc->prec;
    }
}

//Ajout a une postion liste mono
void monoPos(listeMono* tete,int pos){
    listeMono* pc=tete;
    listeMono* k;
    int i=1;
    while(pc!=nullptr){
        if(i+1==pos){
            k=new listeMono;
            k->suiv=pc->suiv ;
            k->info=scanEmploye();
            pc->suiv=k;
        }
            i++;
        pc=pc->suiv;
    }
}

//
void biPos(listeB* tete,int pos){
    listeB* pc=tete;
    listeB* k;
    int i=1;
    while(pc!=nullptr){
        if(i+1==pos){
            k=new listeB;
            k->info = scanEmploye();
            k->suiv=pc->suiv;
            k->prec=pc;
            k->suiv=k;
            k->suiv->prec=k;
        }
        i++;
        pc=pc->suiv;
    }
}
