#ifndef PRODUIT_H_INCLUDED
#define PRODUIT_H_INCLUDED

struct categorie{
    char libelle[20];
    int idC;
};

struct Produit{
    int id=1,code,quantite;
    char libelle[20];
    float prixunitaire;
};

int menuPrincipale();
void addcategorietext();
void addproduitbin();
Produit scanproduit();
categorie scancategorie();
void afficheFProduitbin();
void supprimerFProduitbin();
void supprimerFCategorietext();
void produitpluschere();
void afficheFbinProduitcategorie();
void triePrix();



#endif // PRODUIT_H_INCLUDED
