#include <iostream>
#include"Produit.h"
using namespace std;

int main()
{

    int c;

do{
    c = menuPrincipale();
    system("cls");

    switch(c){
        case 1:
            cout<<"Ajouter une categorie"<<endl;
            addcategorietext();;

            system("Pause");
            break;
        case 2:
            cout<<"Ajouter un Produit"<<endl;
           addproduitbin();

            system("Pause");
            break;

        case 3:
    cout<<"Afficher les Produits"<<endl;
            afficheFProduitbin();
            system("Pause");
            break;

        case 4:
    cout<<"Trier le fichier des produits sur les prix "<<endl;
    cout<<"Affichage avant trie";
    afficheFProduitbin();
    cout<<"Affichage apres trie";
        triePrix();

            system("Pause");
            break;

        case 5:
    cout<<"Afficher le produit le plus chere "<<endl;
    produitpluschere();
    system("Pause");
    break;
        case 6:
    cout<<"Supprimer un produit"<<endl;
            supprimerFProduitbin()
            system("Pause");
            break;

        case 7:
    cout<<" Afficher les produits par categorie"<<endl;
            afficheFbinProduitcategorie();
            system("Pause");
            break;
        case 8:
    cout<<"Supprimer une categorie"<<endl;
                supprimerFCategorietext();
            system("Pause");
            break;
       case 9:
    cout<<"---Quitter Bonne journee"<<endl;
            system("Pause");
            break;
    }


}while(c!=9);






















    return 0;
}
