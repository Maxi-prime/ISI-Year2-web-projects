#include<iostream>
#include"Produit.h"
#include<cstring>
using namespace std;


int menuPrincipale(){
    int choix;
    do{
    cout<<"--- Faites votre choix  : --- "<<endl;
    cout<<"1- Ajouter une categorie"<<endl;
    cout<<"2- Ajouter un Produit"<<endl;
    cout<<"3- Afficher les Produits"<<endl;
    cout<<"4- Trier le fichier des produits sur les prix"<<endl;
    cout<<"5- Afficher le produit le plus chere "<<endl;
    cout<<"6- Supprimer un produit"<<endl;
    cout<<"7- Afficher les produits par categorie"<<endl;
    cout<<"8- Supprimer une categorie"<<endl;
    cout<<"9- Quitter "<<endl;

    cin>>choix;

    }while(choix<1 || choix >9);

    return choix;
}

Produit scanproduit(){
 Produit p,maxp;
    cout<<"Le libelle du produit : ";
    cin>>p.libelle;
    cout<<"Prix unitaire :  ";
    cin>>p.prixunitaire;
    cout<<"Quantite : ";
    cin>>p.quantite;

}

categorie scancategorie(){
    categorie c;
    cout<<"idC : ";
    cin>>c.idC;
    cout<<"Libelle :  ";
    cin>>c.libelle;
}
void addcategorietext(){

     ofstream Fichier("Categorie.txt", ios::app);
    if(!Fichier){
        cout << "Erreur d ouverture du fichier";
        return;
    }
    categorie c = scancategorie();
    Fichier << c.idC <<" " <<c.libelle<<" "<<endl;
    Fichier.close();

}

void addproduitbin(){

     ofstream fichier("Produit.dat",ios::binary | ios::app);
    if(!fichier){
        cout<<"Erreur d'ouverture";
        return;
    }
    Produit p = scanproduit();
    fichier.write((char*)&et,sizeof(Produit));
    fichier.close();

}

void afficheFProduitbin(){

    ifstream fichier("Produit.dat",ios::binary);
    if(!fichier){
        cout<<"Erreur d'ouverture";
        return;
    }
    Produit p;
    int j=1;

    while(fichier.read((char*)&p,sizeof(Produit))){
    cout<<"id : "<<j<<endl;
    cout<<"Libelle : "<<p.libelle<<endl;
     cout<<"Code : "<<j+p.libelle<<endl;
    cout<<"Prix Unitaire : "<<p.prixunitaire<<endl;
    cout<<"Quantite : "<<p.quantite<<endl;
        j++;
    }
    fichier.close();
}

void supprimerFProduitbin(){
     ifstream fichier("Produit.dat",ios::binary);
     ofstream ftemp("tmp.dat", ios::binary | ios::app);
    if(!fichier){
        cout<<"Erreur d'ouverture";
        return;
    }
    Produit p;

    while(fichier.read((char*)&p,sizeof(Produit))){
        if(strcasecmp(et.prenom,"id")!=0){
             ftemp.write((char*)&p,sizeof(Produit));
        }
    }
    fichier.close();
    ftemp.close();
    remove("Produit.dat");
    rename("tmp.dat","Produit.dat");
}


void supprimerFCategorietext(){
    ifstream fichier("Categorie.txt");//Lecture
    ofstream ftemp("temp.txt",ios::app);
    if(!fichier){
        cout<<"Erreur d'ouverture";
        return;
    }
    categorie c;
    int ch;
    while(fichier>>c.idC>>c.libelle){
            cout<<"Quelle est l'attribut a supprimer";
            cout<<"1- idC";
            cout<<"2- libelle";
            cin>>ch;

        if(ch==1){
             ftemp<< c.idC<<" "<<endl;
        }
         if(ch==2){
             ftemp<< c.libelle<<" "<<endl;
        }
    }
    fichier.close();
    ftemp.close();
    remove("Categorie.txt");
    rename("temp.txt","Categorie.txt");

}

void produitpluschere(){
    ifstream fichier("Produit.dat",ios::binary);
    if(!fichier){
        cout<<"Erreur d'ouverture";
        return;
    }
    Produit p;
    int i;
     while(fichier.read((char*)&p,sizeof(Produit))){
        if(i==1){
            maxp=p;
        } else {
            if(p.prixunitaire>maxp){
                maxp=p;
            }
        }
        cout<<"Le produit le plus chere est: "<<maxp;
    }
    fichier.close();

}

void triePrix(){
    ifstream fichier("Produit.dat",ios::binary);
    if(!fichier){
        cout<<"Erreur d'ouverture";
        return;
    }
    Produit p;
    int tab[n];
     while(fichier.read((char*)&p,sizeof(Produit))){
        if(p.prixunitaire>){

        }
    }
    fichier.close();

}

void afficheFbinProduitcategorie(){
}






















