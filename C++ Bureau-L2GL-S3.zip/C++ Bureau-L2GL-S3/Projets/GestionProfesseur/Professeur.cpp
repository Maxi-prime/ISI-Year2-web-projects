#include<iostream>
#include"Professeur.h"
#include<cstring>
using namespace std;
int menuPrincipale(){
    int choix;
    do{
    cout<<"--- Faites votre choix s'il vous plait : --- "<<endl;
    cout<<"1- Ajouter un Professeur(Eviter les doublons de matricules svp)"<<endl;
    cout<<"2- Afficher les Profs"<<endl;
    cout<<"3- Trier la liste dans l'ordre decroissant"<<endl;
    cout<<"4- Transferer dans une liste mono les profs dont salaire < a la moyenne "<<endl;
    cout<<"5- Afficher le prof dont le nom compte plus de lettre 'a'"<<endl;
    cout<<"6- Supprimer un prof(Suivant matricule)"<<endl;
    cout<<"7- Transferer les profs dont role=responsable dans une matrice"<<endl;
    cout<<"8- Afficher liste mono "<<endl;
    cout<<"9- Afficher Matrice "<<endl;
    cout<<"10 --- Quitter--- "<<endl;

    cin>>choix;

    }while(choix<1 || choix >10);

    return choix;
}

int menuAccueil(){

return 0;
}
Professeur scanprofesseur(){
    Professeur p;
    cout<<"Nom : ";
    cin>>p.nom;
    cout<<"Prenom ";
    cin>>p.prenom;
    cout<<"Matricule ";
    cin>>p.matricule;
    cout<<"Salaire: ";
    cin>>p.salaire;
    cout<<"Email: ";
    cin>>p.email;
    cout<<"Role: ";
    cin>>p.role;

    return p;
}

void printprofesseur(Professeur p){
    cout<<"Prenom : "<<p.prenom<<endl;
    cout<<"Nom : "<<p.nom<<endl;
    cout<<"Matricule : "<<p.matricule<<endl;
    cout<<"Salaire : "<<p.salaire<<endl;
    cout<<"Email : "<<p.email<<endl;
    cout<<"Role : "<<p.role<<endl;
}

void printAllprofesseur(listebi* tete){
    listebi* pc=tete;
    while(pc!=nullptr){
        printprofesseur(pc->info);
        pc=pc->suiv;
    }
}

//supprimer a une position
//listebi*supprimerPos(listebi* tete,int pos){
//    listebi* pc;
//    int i=1;
//    if(pos==1 && tete!=nullptr){
//        pc=tete->suiv;
//        if(pc!=nullptr){
//            pc->prec=nullptr;
//        }
//        delete tete;
//        return pc;
//    }
//    pc=tete;
//    listebi* k;
//    while(pc!=nullptr){
//    if(i+1==pos){
//    k=pc->suiv;
//    pc->suiv=k->suiv;
//    if(k->suiv!=nullptr)
//        k->suiv->prec=pc;
//        }
//        i++;
//        pc=pc->suiv;
//    }
//    delete k;
//    return tete;
//}
//
////Supprimer en fonction d1 login
//listebi*supprimer(listebi* tete,char login[]){
//    listebi* pc;
//    pc=tete;
//    listebi* k;
//    while(pc!=nullptr){
//    if(strcasecmp(pc->info.login,login)==0){
//            if(pc->prec==nullptr){
//                tete=pc->suiv;
//                delete pc;
//                return tete;
//            }else{
//             k=pc;
//             pc=pc->prec;
//             pc->suiv=k->suiv;
//             if(k->suiv!=nullptr)
//             k->suiv->prec=pc;
//            }
//        }
//        pc=pc->suiv;
//    }
//    delete k;
//    return tete;
//}
//
//void modifier(listebi* tete,char login[]){
//     listebi* pc = tete;
//     //char res[10];
//    while(pc!=nullptr){
//            if(strcasecmp(pc->info.login,login)==0){
////                    do{
////                        cout<<"Voulez modifier le nom: ";
////                        cin>>res;
////                    }while(res!='oui' || res!='non');
//                cout<<"Votre nouveau nom complet:  ";
//                cin>>pc->info.nomcomplet;
//                cout<<"Votre nouveau nouveau mot de passe:  ";
//                cin>>pc->info.password;
//            }
//        pc=pc->suiv;
//    }
//
//}
//int seconnecter(listebi*  tete,char login[],char password[]){
//    listebi* pc = tete;
//    int ok=0;
//    while(pc!=nullptr){
//            if(strcasecmp(pc->info.login,login)==0 && strcasecmp(pc->info.password,password)==0){
//                ok = 1;
//            }
//        pc=pc->suiv;
//    }
//
//    return ok;



//}
