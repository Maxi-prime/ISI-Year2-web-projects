#include <iostream>
#include"Professeur.h"

using namespace std;

int main()
{

do{
    c = menuPrincipale();
    system("cls");

    switch(c){
        case 1:
        cout<<"Ajouter un Professeur "<<endl;
    k=new listebi;
    k->info=scanprofesseur();
    k->prec=nullptr;
    k->suiv=nullptr;

    if(tete==nullptr){
        tete=k;
    }else{
        fin->suiv=k;
        k->prec=fin;
        }
    fin=k;
    system("Pause");
    break;

        case 2:
    cout<<"Afficher les Profs"<<endl;
    printAllprofesseur(tete);
    system("Pause");
    break;
        case 3:
    cout<<"Trier la liste dans l'ordre decroisant"<<endl;
    //cout<<"Entrer la position: ";
    //cin>>pos;
    //tete = supprimerPos(tete,pos);
    system("Pause");
    break;
        case 4:
    cout<<"Transferer dans une liste mono les profs dont salaire < a la moyenne "<<endl;
    //cout<<"Entrer le login: ";
    //cin>>login;
    //tete = supprimer(tete,login);
    system("Pause");
    break;
        case 5:
    cout<<"Afficher le prof dont le nom compte plus de lettre 'a' "<<endl;
    //cout<<"Son login:  ";
    //cin>>login;
    modifier(tete,login);
    system("Pause");
    break;
        case 6:
    cout<<"Supprimer un prof(Suivant la matricule)"<<endl;
    system("Pause");
    break;
        case 7:
    cout<<"Transferer les profs dont role=responsable dans une matrice"<<endl;
    system("Pause");
    break;
        case 8:
    cout<<"Afficher liste mono"<<endl;
    system("Pause");
    break;
    case 9:
    cout<<"Afficher Matrice"<<endl;
    system("Pause");
    break;
    case 10:
    cout<<"Quitter"<<endl;
    system("Pause");
    break;

    }


}while(c!=10);

delete tete;
delete fin;
delete k;


















    return 0;
}
