#ifndef PROFESSEUR_H_INCLUDED
#define PROFESSEUR_H_INCLUDED

struct Professeur{
    char nom[20],prenom[20],matricule[20],email[40],role[13];
    float salaire;
};

struct listebi{
    Professeur info;
    listebi* prec;
    listebi* suiv;
};
int menuPrincipale();
int menuAccueil();
Professeur scanprofesseur();
void printAllprofesseur(listebi* tete);
void printprofesseur(Professeur p);






















#endif // PROFESSEUR_H_INCLUDED
