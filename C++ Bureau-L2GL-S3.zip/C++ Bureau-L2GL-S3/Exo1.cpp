#include <iostream>
using namespace std;

int verifPremier(int n) {

    if (n <= 1) return 0;
    for (int i = 2; i < n; i++) {
        if (n % i == 0) return 0;
    }
    return 1;
}

int main() {

    int n, val, somme = 0, nbPremiers = 0;

    cout << "Nombre de valeurs � saisir : ";
    cin >> n;

for (int i = 1; i <= n; i++) {

        cout << "Valeur " << i << " : ";
        cin >> val;
        somme = somme + val;

        if (verifPremier(val) == 1) {
            nbPremiers = nbPremiers + 1;
        }
    }


    cout << "Somme = " << somme << "\n";
    cout << "Le nombre de nombres premiers = " << nbPremiers << "\n";










    return 0;
}
