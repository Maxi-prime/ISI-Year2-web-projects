
#include <iostream>
using namespace std;
int * allouertableau(int n){
int * t = new int (n);

return t;

}

int main() {

int n;

do{
    cout<<"la taille du tableau : ";
    cin>>n;
    }while(n<=0);

int * tab=allouertableau(n);



//EXO 10

struct etudiant{
char nom[10];
int age;
float moy;
};

etudiant*et=new etudiant;

cout<<"Nom :";
cin>>e->nom;

cout<<"Age :";
cin>>e->age;

cout<<"moyenne :";
cin>>e->moy;

cout<<"Nom :"<<e->nom<<"Age :"<<e->age<<"MOY :"<<e->moy;



delete b;




















    return 0;
}

