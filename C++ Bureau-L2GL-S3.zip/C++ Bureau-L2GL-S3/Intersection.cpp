#include <iostream>
using namespace std;

void  Affichetableau2(int*tab2,int n2){

   for(int i=0; i<n2 ;i++){
        cout<<tab2[i]<<" ";
    }
}

void  Affichetableau1(int*tab1,int n1){

   for(int i=0; i<n1 ;i++){
        cout<<tab1[i]<<" ";
    }
}

void  Remplissagetableau(int*tab,int taille ){

 cout<<"Remplissage du tableau"<<endl;
    int i;
    for(i=0; i<taille ;i++){

            cout<<"tab ["<<i+1<<"] :";
            cin>>tab[i];
    }

}

int intertab(int*tab1,int n1,int *tab2,int n2,int*tab3){
    int i,j,trouve,k;
    for(i=0;i<n1;i++){
        trouve=0;
        for(j=0;j<n2;j++){
            if(tab1[i]==tab2[j]){
                tab3[]=tab1[i];
            }
        }
    }
}
int main() {

int*tab=new int[n]
























    return 0;
}


