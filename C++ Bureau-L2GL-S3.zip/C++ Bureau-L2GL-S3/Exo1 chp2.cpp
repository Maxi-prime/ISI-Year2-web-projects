#include <iostream>
using namespace std;

int main() {

int z=123;
int*b=&z;


cout<<"La valeur de la variable: "<<*b <<endl;
cout<<"L'adresse de la variable: "<<b <<endl;
cout<<"La valeur point�� par le pointeur: "<<z <<endl;


delete b;




















    return 0;
}

