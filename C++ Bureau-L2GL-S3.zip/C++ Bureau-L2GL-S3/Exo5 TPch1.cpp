#include <iostream>
using namespace std;

typedef struct {
char nom[10];
int age;


}etudiant;


etudiant oletudiant(etudiant tab[],int taille){
    etudiant maxE=tab[0];
    int i;
    for (i=1; i<taille ; i++){
        if(maxE.age<tab[i].age){
            maxE = tab[i];
        }
    }
return maxE;
}

void printetudiant(etudiant et){
    cout<<"Nom: " <<et.nom<<"Age: "<<et.age<<endl;
}
int main() {
    etudiant t[3];
    etudiant mx;

    cout<<"Remplissage du tableau"<<endl;
    for(i=0; i<3 ;i++){

            cout<<"tab[i]: ";
            cin>>tab[i];
    }

mx = oletudiant(t,3);
printetudiant(mx);











    return 0;
}


