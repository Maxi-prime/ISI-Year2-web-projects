#include <iostream>
using namespace std;

void update
int main() {

    int

    cout << "Nombre de valeurs � saisir : ";
    cin >> n;


























    return 0;
}

