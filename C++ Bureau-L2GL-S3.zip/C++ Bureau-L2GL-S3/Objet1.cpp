#include<iostream>
using namespace std;


class Voiture{
private:
    string marque;
    float vitesse;//Atribut

public:
    //string marque;
    //float vitesse;//Atribut
    void setMarque(string m){//Modifier ou saisir la marque
        marque = m;
    }
    void setVitesse(float v){
        vitesse = v;
    }
    string getMarque(){
        return marque;
    }
    float getVitesse;
    return vitesse;
    void demarrer(){
        cout<<"Voiture "<<marque<<" en marche";
    }
};


class Personne{
private:
    string nom;
    string prenom;
    int age;
public:
    Personne(string n,string p,int a){
    nom=n;
    prenom=p;
    age=a;
    }
    void setPrenom(string p)(prenom=p);
    void setNom(string n)(nom=n);
    void setAge(int a)(age=a);
    string getNom()(return nom);
    string getPrenom()(return prenom);
    int getAge()(return age);
    void majoration(){
        if(age>=18){
            cout<<nom<<" est majeur"<<endl;
        }else{
            cout<<nom<<" est mineur";
        }
    }
    void afficher(){
    cout<<"Nom : "<<nom<<"Prenom : "<<"Age : "<<age;
    }
    Destructeur Personne(){}
};

class Etudiant : public Personne {

};
int main(){

    Voiture* v = new Voiture;
    v->setMarque =("Peugeot");
    v->setVitesse=(120);
    v->demarrer();


    Personne* p = new Personne("Diop","Alpha",16);
    p->afficher();
    p->majoration();

}
