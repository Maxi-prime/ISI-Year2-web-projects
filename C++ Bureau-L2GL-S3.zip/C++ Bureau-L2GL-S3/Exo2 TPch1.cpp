#include <iostream>
using namespace std;

void  Affichetableau(int tab[],int taille){

   for(int i=0; i<taille ;i++){
        cout<<tab[i]<<" ";
    }
}
int somtab(int tab[],int taille){
for(int i=0; i<taille ;i++){
        som+=tab[i];
    }
    return som;
}


int main() {

int N;
    do{
        cout<<"Entrer le nombre de cellules: ";
        cin>>N;
    }while(N<=0);


int tab[N];
int i;
int s=somtab(tab,N);

    cout<<"Remplissage du tableau";
    for(i=0; i<N ;i++){

        cout<<"tab[i]: ";
        cin>>tab[i];
    }

cout<<"Affichage du tableau"<< endl;
Affichetableau(tab,N);
cout<<"La somme est "<<s;























    return 0;
}


