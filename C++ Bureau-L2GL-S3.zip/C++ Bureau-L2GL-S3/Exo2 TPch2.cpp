#include <iostream>
using namespace std;

int main() {
    // Déclaration et initialisation d'une variable
    int maVariable = 10;

    std::cout << "Valeur initiale de maVariable : " << maVariable << std::endl;

    // Création d'un pointeur pointant vers maVariable
    int* pointeur = &maVariable;

    std::cout << "Adresse de maVariable : " << &maVariable << std::endl;
    std::cout << "Valeur du pointeur (adresse) : " << pointeur << std::endl;
    std::cout << "Valeur pointée : " << *pointeur << std::endl;

    // Modification de la variable via le pointeur
    std::cout << "\nModification via le pointeur..." << std::endl;
    *pointeur = 42;

    // Vérification que le changement est visible directement
    std::cout << "Valeur de maVariable après modification : " << maVariable << std::endl;
    std::cout << "Valeur pointée après modification : " << *pointeur << std::endl;

    // Vérification supplémentaire
    if (maVariable == 42 && *pointeur == 42) {
        std::cout << "\n✓ Succès : La modification via le pointeur est bien visible directement !" << std::endl;
    } else {
        std::cout << "\n✗ Erreur : Les valeurs ne correspondent pas !" << std::endl;
    }

    return 0;




int main() {
    // Déclaration et initialisation d'un tableau d'entiers
    int tableau[] = {10, 20, 30, 40, 50};
    const int taille = 5;

    std::cout << "Parcours du tableau avec un pointeur :" << std::endl;

    // Création d'un pointeur pointant vers le début du tableau
    int* pointeur = tableau;  // équivalent à &tableau[0]

    // Parcours du tableau avec le pointeur
    for (int i = 0; i < taille; i++) {
        std::cout << "Element " << i << " : " << *pointeur << std::endl;
        pointeur++;  // Déplacement vers l'élément suivant
    }

    // Version alternative avec une boucle while
    std::cout << "\nParcours alternatif avec while :" << std::endl;
    int* ptr = tableau;  // Retour au début du tableau
    int compteur = 0;

    while (ptr < tableau + taille) {
        std::cout << "Element " << compteur << " : " << *ptr << std::endl;
        ptr++;
        compteur++;
    }

    // Version montrant les adresses mémoire
    std::cout << "\nAvec les adresses mémoire :" << std::endl;
    int* p = tableau;

    for (int i = 0; i < taille; i++) {
        std::cout << "Adresse : " << p << " -> Valeur : " << *p << std::endl;
        p++;
    }

    return 0;
}
}
