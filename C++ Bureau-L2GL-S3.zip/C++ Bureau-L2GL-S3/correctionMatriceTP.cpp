#include<iostream>
using namespace std;
int main(){
    int L,C;
    do{
        cout<<"Le nombre de ligne: ";
        cin>>L;
    }while(L<=0);
    do{
        cout<<"Le nombre de colonne: ";
        cin>>C;
    }while(C<=0);
    int** m = new int*[L];//etape 1 initialiser le nombre de ligne
    for(int i=0;i<L;i++){
        m[i]= new int[C];
    }


     cout<<"Remplissage de la matrice "<<endl;
    for(int i=0;i<L;i++){
        for(int j=0;j<C;j++){
            cout<<"["<<i<<"]["<<j<<"]: ";
            cin>>m[i][j];
        }
    }
    cout<<"Affichage de la matrice avant"<<endl;
    for(int i=0;i<L;i++){
        for(int j=0;j<C;j++){
            cout<<m[i][j]<< " ";
        }
        cout<<endl;
    }

    int tmp;
    for(int i=0;i<L;i++){
        for(int j=i+1;j<L;j++){
            if(m[i][0]<m[j][0]){
                tmp = m[i][0];
                m[i][0]=m[j][0];
                m[j][0]=tmp;
            }
        }
    }

    cout<<"Affichage de la matrice apres tri "<<endl;
    for(int i=0;i<L;i++){
        for(int j=0;j<C;j++){
            cout<<m[i][j]<< " ";
        }
        cout<<endl;
    }

    for(int i=0;i<L/2;i++){
        tmp=m[i][C-1];
        m[i][C-1]=m[L-1-i][C-1];
        m[L-1-i][C-1]=tmp;
    }

    cout<<"Affichage de la matrice apres inversion "<<endl;
    for(int i=0;i<L;i++){
        for(int j=0;j<C;j++){
            cout<<m[i][j]<< " ";
        }
        cout<<endl;
    }


      for(int i=0;i<L;i++){
        delete[] m[i];
    }
    delete[] m;
}
