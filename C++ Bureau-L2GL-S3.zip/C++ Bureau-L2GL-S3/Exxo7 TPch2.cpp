#include <iostream>
using namespace std;

int main() {

int* k=new int;
*k=10;

cout<<*k <<endl;

delete k;




















    return 0;
}


