#include <iostream>
using namespace std;

struct listeb{
int info;
listeb*prec;
listeb*suiv;
};

void gd(listeb*tete){
    listeb*pc=tete;
    while(pc!=nullptr){
        cout<<pc->info<<endl;
        pc=pc->suiv;
    }
}

void dg(listeb*tete){
    listeb*pc=tete;
    cout<<"Affichage droite vers la gauche";
    while(pc!=nullptr){
        cout<<pc->info<<endl;
        pc=pc->prec;
    }
}

int main() {

listeb* tete=nullptr;
listeb* fin=nullptr;
listeb* k;

    for(int i=1; i<=3; i++){
        k=new listeb;
        k->suiv=nullptr;
        k->prec=nullptr;
        k->info=i;

        if(tete==nullptr){
            tete=k;
            fin=k;
        }else{
            fin->suiv=k;
            k->prec=fin;
            fin=k;
        }
    }
gd(tete);
dg();



















    return 0;
}


