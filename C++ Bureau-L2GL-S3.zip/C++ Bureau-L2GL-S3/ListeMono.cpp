#include<iostream>
#include<cstring>
using namespace std;
struct listeMono{
    int info;
    listeMono* suiv;
};
void afficheListe(listeMono* tete){
    listeMono* p=tete;
    while(p!=nullptr){
        cout<<p->info<<endl;
        p=p->suiv;
    }
    delete p;
}

void afficheListeC(listeMono* tete){
    listeMono* p=tete;

    do{
        cout<<p->info<<endl;
        p=p->suiv;

    }while(p!=tete);
    delete p;
}
int main(){
    //creation
    listeMono* tete=nullptr;
    listeMono* fin;
    listeMono* k;
    char response[20];
    do{
        k = new listeMono;
        k->suiv=nullptr;
        cout<<"Entrer un entier : ";
        cin>>k->info;
        if(tete==nullptr){
            tete = k;
        }else{
            fin->suiv = k;
        }
        fin=k;
        fin->suiv=tete;
        cout<<"un nouveau element ? ";
        cin>>response;
    }while(strcasecmp(response,"oui")==0);
    afficheListeC(tete);
    delete tete;
    delete fin;
    delete k;
}
