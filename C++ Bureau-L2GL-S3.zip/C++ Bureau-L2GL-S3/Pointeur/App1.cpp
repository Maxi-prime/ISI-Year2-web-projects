#include<iostream>
using namespace std;

void echange(int *x,int *y){
    int tmp;

    tmp= *x;
    *x = *y;
    *y = tmp;
}

int main(){

    int a = 12;
    int b = 19;
    cout<<"Affichage avant echange : " <<a<<" "<<b<<endl;
    echange(&a, &b);
    cout<<"Affichage avant echange : "<<a<<" "<<b;




























return 0;
}
