#include<iostream>
using namespace std;

struct Etudiant{ //Exo10 et 11
    char nom[10];
    int age;
    float moy;
};



//int* allouertableau(int n){ (Exo9)
//    int* t = new int[n];
//    return t;
//}
int main(){
    //Exo3
//    int tab[3] = {34,2,1};
//    int* t = tab;
//
//    int i;
//    for(i=0; i<3; i++){
//        cout<<*(t+i)<<endl;
//    }
//    cout<<*t;

    //Exo4
//    char ch[] = "Bonjour";
//    char* c=ch;
//    while(*c!='\0'){
//        cout<<*c<<endl;
//        c++;
//    }


    //Exo6
//    int k=10;
//    int* kp = &k;
//    int** p = &kp;
//    cout<<"Valeur a travers k: "<<k<<endl;
//    cout<<"Valeur a travers kp: "<<*kp<<endl;
//    cout<<"Valeur a travers p: "<<**p<<endl;
//    cout<<"Adresse p: "<<&k<<endl;

    //Exo7
//    int* k = new int;
//    *k=10;
//    cout<<*k;
//    delete k;

    //Exo8 Tableaux Dynamique
//    int n;
//    do{
//        cout<<"La taille du tableau svp : ";
//        cin>>n;
//    }while(n<=0);
//    int* tab = new int[n];
//    int i;
//    float moy,som=0;
//
//        cout<<"Remplissage du tableau "<<endl;
//    for(i=0; i<n; i++){
//        cout<<"v"<<i+1<<":"<<endl;
//        cin>>tab[i];
//        som+=tab[i];
//    }
//
//      //cout<<"Une autre valeur "<<endl;
//      //cin>>tab[i];
//
//
//       cout<<"Affichage du tableau "<<endl;
//    for(i=0; i<n; i++){
//        cout<<tab[i]<<" "<<endl;
//    }
//    moy = som/n;
//    cout<<"La moyenne donne "<<moy;
//        //cout<<"Le dernier element a la position "<<i<<"est :"<<tab[i];
//    delete[] tab;


        //Exo9 Allouer Tableau

//int n;
//    do{
//        cout<<"La taille du tableau svp : ";
//        cin>>n;
//    }while(n<=0);
//    int* tab = allouertableau(n);
//    int i;
//            cout<<"Remplissage du tableau "<<endl;
//    for(i=0; i<n; i++){
//        cout<<"v"<<i+1<<":"<<endl;
//        cin>>tab[i];
//    }
//       cout<<"Affichage du tableau "<<endl;
//    for(i=0; i<n; i++){
//        cout<<tab[i]<<" "<<endl;
//    }

    //Exo10
//
//    Etudiant* e = new Etudiant;
//    cout<<"Nom: ";
//    cin>>e->nom;
//    cout<<"Age: ";
//    cin>>e->age;
//    cout<<"moyenne: ";
//    cin>>e->moy;
//    cout<<"Nom: "<<e->nom<<"Age: "<<e->age<<"Moyenne: "<<e->moy;

        //Exo11
 int n;
    do{
        cout<<"Le Nombre des etudiants : ";
        cin>>n;
    }while(n<=0);

    Etudiant* ets = new Etudiant[n];
    Etudiant max1;

    cout<<"Remplissage du tableau  "<<endl;
  for(int i=0; i<n; i++){
    cout<<"Nom: ";
    cin>>ets[i].nom;
    cout<<"Age: ";
    cin>>ets[i].age;
    cout<<"moyenne: ";
    cin>>ets[i].moy;

    if(i==0){
        max1 = ets[i];
    }else if(ets[i].moy>max1.moy){
        max1=ets[i];
     }
  }


    cout<<"Affichage du tableau "<<endl;
    for(int i=0; i<n; i++){
    cout<<"Nom: "<<ets[i].nom<<" Age: "<<ets[i].age<<" Moyenne: "<<ets[i].moy;
    }
    cout<<"Le Max :"<<endl;
    cout<<"Nom: "<<max1.nom<<" Age: "<<max1.age<<" Moyenne: "<<max1.moy;

        //Exo13






    return 0;
}
