#include<iostream>
using namespace std;

//Module pour Remplir un Tableau
void remplirTab(int t[],int n){
    int i;
    for(i=0; i<n; i++){
        cout<<"["<<(i+1)<<"]: ";
        cin>>t[i];
          }
          cout<<endl;
    }

//Module pour Afficher un Tableau
void printTab(int t[],int n){
    int i;
    for(i=0; i<n; i++){
        cout<<t[i]<<" ";

          }
          cout<<endl;
        }
//T1 - T2 les elements qui se trouve dans T1 mais pas dans T2
int T1moinsT2Tableau(int T1[],int n1,int T2[],int n2,int T3[]){
    int i,j,ok,ok2,k,c=0;
    for(i=0; i<n1; i++){
            ok=0;
        for(j=0; j<n2; j++){
            if(T1[i] == T2[j]){
                ok=1;
                break;
            }
        }
        if(ok==1){
            ok2=0;
            for(k=0; k<c; k++){
                if(T1[i]==T3[k]){
                    ok2=1;
                    break;
                }
            }
            if(ok2==0){
                T3[c]=T1[i];
                c++;
            }
        }
    }

       for(i=0; i<n1; i++){
            ok=0;
        for(j=0; j<n2; j++){
            if(T1[i] == T2[j]){
                ok=1;
            }
        }
        if(ok==0){
            ok2=0;
            for(k=0; k<c; k++){
                if(T1[i]==T3[k]){
                    ok2=1;
                    break;
                }
            }
            if(ok2==0){
                T3[c]=T1[i];
                c++;
            }
        }
    }


    return c;
}


//Module pour faire Intersection d1 tableau les valeurs qui sont dans T1 et T2 sans doublon
int interTableau(int T1[],int n1,int T2[],int n2,int T3[]){
    int i,j,ok,ok2,k,c=0;
    for(i=0; i<n1; i++){
            ok=0;
        for(j=0; j<n2; j++){
            if(T1[i] == T2[j]){
                ok=1;
                c++;
                break;
            }
        }
        if(ok==1){
            ok2=0;
            for(k=0; k<c; k++){
                if(T1[i]==T3[k]){
                    ok2=1;
                    break;
                }
            }
            if(ok2==0){
                T3[c]=T1[i];
                c++;
            }
        }
    }

    for(i=0; i<n2; i++){
            ok=0;
        for(j=0; j<n1; j++){
            if(T2[i] == T1[j]){
                ok=1;
                //c++;
                break;
            }
        }
        if(ok==1){
            ok2=0;
            for(k=0; k<c; k++){
                if(T2[i]==T3[k]){
                    ok2=1;
                    break;
                }
            }
            if(ok2==0){
                T3[c]=T2[i];
                c++;
            }
        }
    }

    return c;
}

//Module pour faire Union d1 tableau les valeurs qui sont dans T1 et T2 sans doublon
int unionTableau(int T1[],int n1,int T2[],int n2,int T3[]){
        int i,j,c=0,ok;
        for(i=0; i<n1; i++){
            ok=0;
            for(j=0; j<c; j++){
                if(T1[i]==T3[j])
                    ok=1;
            }
            if(ok==0){
                T3[c]=T1[i];
                c++;
            }
        }
         for(i=0; i<n2; i++){
            ok=0;
            for(j=0; j<c; j++){
                if(T2[i]==T3[j])
                    ok=1;
            }
            if(ok==0){
                T3[c]=T2[i];
                c++;
            }
        }
        return c;

}

int main(){

int n1,n2;
    do{
        cout<<"La taille du tableau 1 : ";
        cin>>n1;
    }while(n1<=0);
    do{
        cout<<"La taille du tableau 2 : ";
        cin>>n2;
    }while(n2<=0);

    int T1[n1],T2[n2],T3[n1+n2],texact=0;
    remplirTab(T1,n1);
    remplirTab(T2,n2);

    cout<<"Affichage du tableau 2 :"<<endl;
    printTab(T2,n2);

    texact = unionTableau(T1,n1,T2,n2,T3);
    cout<<"T1 union T2 : "<<endl;
    printTab(T3,texact);

    texact = interTableau(T1,n1,T2,n2,T3);
    cout<<"T1 inter T2 : "<<endl;
    printTab(T3,texact);

    texact = T1moinsT2Tableau(T1,n1,T2,n2,T3);
    cout<<"T1 - T2 : "<<endl;
    printTab(T3,texact);










return 0;
}
