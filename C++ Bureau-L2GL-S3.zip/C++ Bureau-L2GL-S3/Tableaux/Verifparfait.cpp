#include <iostream>
using namespace std;

//void afficherEntier(int v){
//    cout<<"L'entier est "<<v;
//}
//void verifparfait(int val){
//    int i,som=0;
//    for(i=1; i<=val-1; i++){
//        if(val%i==0){
//            som = som +1;
//        }
//    }
//    if(som==v){
//        return 1;
//    }else{
//        return 0;
//    }
//}
//
//
//void affichestring(char nom[]){
//    cout<<"Le nom est :"<<nom;
//}


void afficheTab(int tab[],int N){

    int i;
    cout"Affichage du tableau"<<endl;
    for(i=0; i<n; i++){
        cout<<tab[i];
    }
}
int main() {

//    int j;
//cout<<"Entrer un entier";
//cin>>j;afficherEntier(j);
//
//char v[10];
//cout<<"Entrer votre nom:";
//gets(v);


int t[5];

cout<<"Remplissage du tableau";
for(i=0; i<5; i++{
cout<<tab[i]<<i+1;
cin>>t[i];
}


afficheTab(t,5);
















    return 0;
}


