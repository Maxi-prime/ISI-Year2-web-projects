#include<iostream>
using namespace std;

class Voiture{
    // protected
  private: //en Privee
    string marque;
    float vitesse;

  public: // En mode public on peut y acceder a travers la variable
    void setMarque(string m){ // set pour modifier et get pour recuperer
    marque = m;
    }
    void setVitesse(float v){
    vitesse = v;
    }
    string getMarque(){
    return marque;
    }
    float getVitess(){
    return vitesse;
    }
    void demarrer(){
        cout<<"Voiture "<<marque<<" en marche";
    }
    void somme(int a,int b){
        int s = a+b;
        cout<<"La somme donne "<<s;
    }
    void somme(int a){
        cout<<"La somme est "<<a;
    }

};

class Personne{
private:
    string nom;
    string prenom;
    int age;
public:
//    Personne(string n,string p,int a){
//        nom=n;
//        prenom=p;
//        age=a;
//    } // Methode personne avec arguent




    void setPrenom(string p){prenom=p;}
    void setNom(string n){nom=n;}
    void setAge(int a){age=a;}
    string getNom(){return nom;}
    string getPrenom(){return prenom;}
    int getAge(){return age;}
    void printBonjour(){
        cout<<"Bonjour personne"<<endl;
    }
    void majoration(){
        if(age>=18){
            cout<<nom<<" est majeur"<<endl;
        }else {
            cout<<nom<<" est mineur"<<endl;
        }
    }
    void afficher(){
        cout<<"Nom: "<<nom<<" Prenom: "<<prenom<<" Age: "<<age<<endl;
    }
    //-Personne(){}
};

class Etudiant : public Personne{ //Heritage de la class mere
private :
    string matricule;
public :
    Etudiant(){}
};

int main(){

    //Personne* p = new Personne("Diop","Alpha",18);
//    p->afficher();
//    p->majoration();
//        Personne* p = new Personne;
        Etudiant* e = new Etudiant;
       p->printBonjour();
       e->setNom("Diop");
       e->setPrenom("Alpha");
       e->setAge(21);
       e->afficher();

//        cout<<endl;
//        e->printBonjour();




//    Voiture* v = new Voiture;
//    v->setMarque=("Peugeot");
//    v->setVitesse=(120);
//    //V->demarrer();
//    cout<<"La marque est "<<v->getMarque();
















}
