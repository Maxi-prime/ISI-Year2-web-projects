#include <iostream>
using namespace std;

int main() {

//int N;
//    do{
//        cout<<"Entrer le nombre de cellules: ";
//        cin>>N;
//    }while(N<=0);
//
//
//int tab[N];
//int i;
//
//    cout<<"Remplissage du tableau";
//
//    for(i=0; i<N ;i++){
//        do{
//            cout<<"tab[i]: ";
//            cin>>tab[i];
//
//        }while(tab[i]<=0);
//
//    }
//
//    cout<<"Affichage du tableau avant inversion"<< endl;
//    for(i=0;i<N;i++){
//        cout<<tab[i]<<endl;
//    }
//
//int j=N-1,tmp;
//for(i=0; i<N/2 ;i++){
//    tmp=tab[i];
//    tab[i]=tab[j];
//    tab[j]=tmp;
//    j--;
//}
//cout<<"Affichage du tableau apres inversion"<< endl;
//    for(i=0;i<N;i++){
//        cout<<tab[i]<<endl;
//    }
//
//
//// Tableaux de N etudiants Nom prenom age
//int N;
//    do{
//        cout<<"Entrer le nombre de cellules: ";
//        cin>>N;
//    }while(N<=0);
//
//  etudiant T[N];
//   int i;
//   cout<<"Remplissage"<<endl;
//     for(i=0; i<N ;i++){
//       cout<<"Nom"<<i+1<<endl;
//        cin>>T[i].nom;
//     }
//


// Matrice

int T[2][3];
T[0][0]=10;
cout<<T[0][0];


int N[3][3];
int i,j;
for(i=0; i<3 ;i++){
    for(j=0; j<3 ; j++){
//        cout<<i<<"/"<<j<<":";
//        cin>>M[i][j];

        cout<<M[i][j]<<" ";
    }
}











    return 0;
}
