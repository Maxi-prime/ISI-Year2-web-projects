#include <iostream>
using namespace std;

int main() {

int n;

do{
    cout<<"la taille du tableau : ";
    cin>>n;
    }while(n<=0);

int*tab=new int(n);

int i;
float som=0,moy;

cout<<"Remplissage du tableau";
for(i=0; i<n; i++){
    cout<<"V"<<i+1<<":";
    cin>>tab[i];
    som+=tab[i];
}
//cout<<"Une autre valeur";
//cin>>tab[i];

cout<<"Affichage du tableau:"<<endl;

for(i=0; i<n; i++){
    cout<<tab[i]<<" "<<endl;

}
moy=som/n;
cout<<"La moyenne donne :"<<moy;
//cout<<"le dernier element a la position 5 est  "<<i<<tab[i]endl;


delete[] tab;




















    return 0;
}


