# CRUD Java - Systeme d'ecole (Etudiants) + Connexion utilisateur

Projet Maven complet, pret a etre ouvert dans IntelliJ, qui montre comment
faire un CRUD (Create, Read, Update, Delete) en Java avec une base de donnees
MySQL, ainsi qu'un systeme de connexion (login / inscription) d'utilisateur.

Ce projet est concu comme un modele reutilisable : pour un futur CRUD,
il suffit de copier la structure (model / dao / util) et d'adapter les noms
de classes et les requetes SQL.

## Structure du projet

```
crud-ecole-java/
  pom.xml                                  -> configuration Maven
  src/main/resources/database.sql          -> script de creation de la base
  src/main/java/com/ecole/
      Main.java                            -> menu principal (connexion + CRUD)
      model/
          Student.java                     -> modele Etudiant
          User.java                        -> modele Utilisateur
      dao/
          DatabaseConnection.java          -> connexion a MySQL
          StudentDAO.java                  -> operations CRUD sur les etudiants
          UserDAO.java                     -> inscription / connexion utilisateur
      util/
          PasswordUtil.java                -> hashage des mots de passe (SHA-256)
```

## Installation

1. Installer MySQL sur ta machine si ce n'est pas deja fait.
2. Ouvrir MySQL (Workbench, ligne de commande, ou autre) et executer le
   fichier `src/main/resources/database.sql`. Cela va creer la base
   `ecole_db` avec les tables `students` et `users`.
3. Ouvrir le dossier `crud-ecole-java` dans IntelliJ :
   - File > Open > selectionner le dossier `crud-ecole-java`.
   - IntelliJ detecte automatiquement le fichier `pom.xml` et telecharge
     les dependances Maven (connecteur MySQL).
4. Ouvrir `DatabaseConnection.java` et adapter si besoin :
   - `URL` (nom d'hote et port de ta base)
   - `USER` (utilisateur MySQL, "root" par defaut)
   - `PASSWORD` (mot de passe MySQL)
5. Executer la classe `Main.java` (clic droit > Run 'Main.main()').

## Utilisation

Au lancement du programme :
1. Tu choisis "2. Creer un compte" pour creer ton premier utilisateur.
2. Ensuite tu choisis "1. Se connecter" avec ce compte.
3. Une fois connecte, tu arrives sur le menu CRUD des etudiants :
   ajouter, afficher, rechercher, modifier, supprimer.

## Points importants a retenir pour reutiliser ce modele

- `DatabaseConnection` centralise la connexion : un seul endroit a modifier
  si les identifiants de la base changent.
- Chaque entite (Student, User) a son propre DAO avec les methodes
  CRUD classiques : add / getAll / getById / update / delete.
- Les requetes SQL utilisent des `PreparedStatement` (avec des `?`) pour
  eviter les injections SQL. Ne jamais concatener directement les valeurs
  dans la requete SQL.
- Les mots de passe ne sont jamais stockes en clair, ils sont hashes avec
  `PasswordUtil` avant d'etre enregistres en base.
- `Main.java` separe bien la logique de connexion (`authenticate`) de la
  logique metier du CRUD (`showStudentMenu`), ce qui rend le code plus
  facile a lire et a reutiliser pour un autre projet.
