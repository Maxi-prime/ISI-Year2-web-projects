-- Script de creation de la base de donnees pour le systeme d'ecole
-- A executer une seule fois dans MySQL avant de lancer le programme Java

CREATE DATABASE IF NOT EXISTS ecole_db;
USE ecole_db;

-- Table des utilisateurs (pour le systeme de connexion / authentification)
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(256) NOT NULL,
    role VARCHAR(20) NOT NULL DEFAULT 'ADMIN'
);

-- Table des etudiants (table principale du CRUD)
CREATE TABLE IF NOT EXISTS students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    course VARCHAR(100) NOT NULL,
    grade DOUBLE NOT NULL
);

-- Un utilisateur de depart pour pouvoir tester la connexion tout de suite
-- Identifiant : admin | Mot de passe : admin123
-- (le mot de passe est hashe automatiquement par le programme Java, celui-ci est juste un exemple)
