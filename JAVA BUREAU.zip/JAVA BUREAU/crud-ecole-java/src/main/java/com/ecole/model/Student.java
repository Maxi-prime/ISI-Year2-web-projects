package com.ecole.model;

/**
 * Classe modele qui represente un etudiant.
 * Chaque attribut correspond a une colonne de la table "students" en base de donnees.
 */
public class Student {

    private int id;
    private String firstName;
    private String lastName;
    private String email;
    private String course;
    private double grade;

    // Constructeur vide, utile pour creer un objet avant de remplir ses champs
    public Student() {
    }

    // Constructeur sans id, utile quand on cree un nouvel etudiant (l'id est genere par la base)
    public Student(String firstName, String lastName, String email, String course, double grade) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.course = course;
        this.grade = grade;
    }

    // Constructeur complet, utile quand on recupere un etudiant deja existant depuis la base
    public Student(int id, String firstName, String lastName, String email, String course, double grade) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.course = course;
        this.grade = grade;
    }

    // Getters et Setters : permettent d'acceder et de modifier les attributs prives

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public double getGrade() {
        return grade;
    }

    public void setGrade(double grade) {
        this.grade = grade;
    }

    // Methode toString : sert a afficher les informations de l'etudiant de maniere lisible
    @Override
    public String toString() {
        return "ID: " + id +
                " | Nom: " + lastName +
                " | Prenom: " + firstName +
                " | Email: " + email +
                " | Cours: " + course +
                " | Note: " + grade;
    }
}
