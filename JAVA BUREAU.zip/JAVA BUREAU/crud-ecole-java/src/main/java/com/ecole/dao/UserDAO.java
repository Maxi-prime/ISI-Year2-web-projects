package com.ecole.dao;

import com.ecole.model.User;
import com.ecole.util.PasswordUtil;

import java.sql.*;

/**
 * DAO pour l'entite User.
 * Gere l'inscription et la connexion d'un utilisateur.
 */
public class UserDAO {

    // Inscription : cree un nouvel utilisateur avec un mot de passe hashe
    public boolean registerUser(String username, String plainPassword, String role) {
        // On verifie d'abord que le nom d'utilisateur n'existe pas deja
        if (findUserByUsername(username) != null) {
            System.out.println("Ce nom d'utilisateur existe deja.");
            return false;
        }

        String sql = "INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            String hashedPassword = PasswordUtil.hashPassword(plainPassword);

            stmt.setString(1, username);
            stmt.setString(2, hashedPassword);
            stmt.setString(3, role);

            stmt.executeUpdate();
            System.out.println("Utilisateur cree avec succes.");
            return true;

        } catch (SQLException e) {
            System.out.println("Erreur lors de l'inscription : " + e.getMessage());
            return false;
        }
    }

    // Connexion : verifie que le nom d'utilisateur existe et que le mot de passe correspond
    public User login(String username, String plainPassword) {
        User user = findUserByUsername(username);

        if (user == null) {
            System.out.println("Nom d'utilisateur introuvable.");
            return null;
        }

        boolean isPasswordCorrect = PasswordUtil.verifyPassword(plainPassword, user.getPasswordHash());

        if (isPasswordCorrect) {
            System.out.println("Connexion reussie. Bienvenue " + user.getUsername() + " !");
            return user;
        } else {
            System.out.println("Mot de passe incorrect.");
            return null;
        }
    }

    // Recherche un utilisateur par son nom d'utilisateur, utile pour login() et registerUser()
    private User findUserByUsername(String username) {
        String sql = "SELECT * FROM users WHERE username = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return new User(
                        rs.getInt("id"),
                        rs.getString("username"),
                        rs.getString("password_hash"),
                        rs.getString("role")
                );
            }

        } catch (SQLException e) {
            System.out.println("Erreur lors de la recherche de l'utilisateur : " + e.getMessage());
        }

        return null;
    }
}
