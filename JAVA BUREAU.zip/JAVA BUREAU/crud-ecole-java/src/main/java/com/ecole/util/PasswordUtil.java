package com.ecole.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Classe utilitaire pour hasher les mots de passe avec l'algorithme SHA-256.
 * On ne doit jamais enregistrer un mot de passe en clair dans la base de donnees.
 */
public class PasswordUtil {

    // Transforme un mot de passe en clair en une empreinte (hash) impossible a inverser
    public static String hashPassword(String plainPassword) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = digest.digest(plainPassword.getBytes());

            // Conversion des octets en chaine hexadecimale lisible
            StringBuilder hexString = new StringBuilder();
            for (byte b : hashBytes) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }
            return hexString.toString();

        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Erreur lors du hashage du mot de passe", e);
        }
    }

    // Verifie qu'un mot de passe saisi correspond bien au hash enregistre en base
    public static boolean verifyPassword(String plainPassword, String hashedPassword) {
        String hashOfInput = hashPassword(plainPassword);
        return hashOfInput.equals(hashedPassword);
    }
}
