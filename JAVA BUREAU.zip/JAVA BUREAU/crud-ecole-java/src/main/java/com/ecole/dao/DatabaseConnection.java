package com.ecole.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Classe utilitaire qui centralise la connexion a la base de donnees.
 * Ainsi, si on change de base (nom, mot de passe, port...), on ne modifie qu'un seul endroit.
 */
public class DatabaseConnection {

    // Modifie ces informations selon ta propre configuration MySQL
    private static final String URL = "jdbc:mysql://localhost:3306/ecole_db";
    private static final String USER = "root";
    private static final String PASSWORD = "root";

    // Methode statique qui retourne une nouvelle connexion a chaque appel
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
