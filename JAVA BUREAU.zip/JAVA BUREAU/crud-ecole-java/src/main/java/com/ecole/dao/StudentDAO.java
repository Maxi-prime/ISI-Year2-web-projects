package com.ecole.dao;

import com.ecole.model.Student;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO (Data Access Object) pour l'entite Student.
 * Cette classe contient toutes les operations CRUD (Create, Read, Update, Delete)
 * liees a la table "students".
 *
 * C'est ce fichier qui sert de modele reutilisable : pour un autre CRUD,
 * il suffit de remplacer "Student" par une autre entite et d'adapter les requetes SQL.
 */
public class StudentDAO {

    // ---------- CREATE : ajouter un nouvel etudiant ----------
    public void addStudent(Student student) {
        String sql = "INSERT INTO students (first_name, last_name, email, course, grade) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, student.getFirstName());
            stmt.setString(2, student.getLastName());
            stmt.setString(3, student.getEmail());
            stmt.setString(4, student.getCourse());
            stmt.setDouble(5, student.getGrade());

            stmt.executeUpdate();
            System.out.println("Etudiant ajoute avec succes.");

        } catch (SQLException e) {
            System.out.println("Erreur lors de l'ajout de l'etudiant : " + e.getMessage());
        }
    }

    // ---------- READ : recuperer tous les etudiants ----------
    public List<Student> getAllStudents() {
        List<Student> students = new ArrayList<>();
        String sql = "SELECT * FROM students";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                students.add(mapResultSetToStudent(rs));
            }

        } catch (SQLException e) {
            System.out.println("Erreur lors de la recuperation des etudiants : " + e.getMessage());
        }

        return students;
    }

    // ---------- READ : recuperer un etudiant par son id ----------
    public Student getStudentById(int id) {
        String sql = "SELECT * FROM students WHERE id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return mapResultSetToStudent(rs);
            }

        } catch (SQLException e) {
            System.out.println("Erreur lors de la recherche de l'etudiant : " + e.getMessage());
        }

        return null; // aucun etudiant trouve avec cet id
    }

    // ---------- UPDATE : modifier un etudiant existant ----------
    public void updateStudent(Student student) {
        String sql = "UPDATE students SET first_name = ?, last_name = ?, email = ?, course = ?, grade = ? WHERE id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, student.getFirstName());
            stmt.setString(2, student.getLastName());
            stmt.setString(3, student.getEmail());
            stmt.setString(4, student.getCourse());
            stmt.setDouble(5, student.getGrade());
            stmt.setInt(6, student.getId());

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Etudiant modifie avec succes.");
            } else {
                System.out.println("Aucun etudiant trouve avec cet id.");
            }

        } catch (SQLException e) {
            System.out.println("Erreur lors de la modification de l'etudiant : " + e.getMessage());
        }
    }

    // ---------- DELETE : supprimer un etudiant ----------
    public void deleteStudent(int id) {
        String sql = "DELETE FROM students WHERE id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Etudiant supprime avec succes.");
            } else {
                System.out.println("Aucun etudiant trouve avec cet id.");
            }

        } catch (SQLException e) {
            System.out.println("Erreur lors de la suppression de l'etudiant : " + e.getMessage());
        }
    }

    // Methode privee qui transforme une ligne du ResultSet en objet Student
    // Evite de repeter le meme code dans getAllStudents() et getStudentById()
    private Student mapResultSetToStudent(ResultSet rs) throws SQLException {
        return new Student(
                rs.getInt("id"),
                rs.getString("first_name"),
                rs.getString("last_name"),
                rs.getString("email"),
                rs.getString("course"),
                rs.getDouble("grade")
        );
    }
}
