package com.ecole;

import com.ecole.dao.StudentDAO;
import com.ecole.dao.UserDAO;
import com.ecole.model.Student;
import com.ecole.model.User;

import java.util.List;
import java.util.Scanner;

/**
 * Classe principale du programme.
 * Etape 1 : l'utilisateur doit se connecter (ou s'inscrire).
 * Etape 2 : une fois connecte, il accede au menu CRUD des etudiants.
 */
public class Main {

    private static final Scanner scanner = new Scanner(System.in);
    private static final StudentDAO studentDAO = new StudentDAO();
    private static final UserDAO userDAO = new UserDAO();

    public static void main(String[] args) {
        User currentUser = authenticate();

        if (currentUser != null) {
            showStudentMenu();
        } else {
            System.out.println("Impossible de continuer sans etre connecte. Fin du programme.");
        }
    }

    // ---------- SYSTEME DE CONNEXION ----------
    private static User authenticate() {
        while (true) {
            System.out.println("\n===== BIENVENUE =====");
            System.out.println("1. Se connecter");
            System.out.println("2. Creer un compte");
            System.out.println("3. Quitter");
            System.out.print("Choix : ");

            String choice = scanner.nextLine();

            switch (choice) {
                case "1" -> {
                    System.out.print("Nom d'utilisateur : ");
                    String username = scanner.nextLine();
                    System.out.print("Mot de passe : ");
                    String password = scanner.nextLine();

                    User user = userDAO.login(username, password);
                    if (user != null) {
                        return user; // connexion reussie, on sort de la boucle
                    }
                }
                case "2" -> {
                    System.out.print("Choisissez un nom d'utilisateur : ");
                    String username = scanner.nextLine();
                    System.out.print("Choisissez un mot de passe : ");
                    String password = scanner.nextLine();

                    userDAO.registerUser(username, password, "ADMIN");
                }
                case "3" -> {
                    return null; // l'utilisateur quitte sans se connecter
                }
                default -> System.out.println("Choix invalide, reessayez.");
            }
        }
    }

    // ---------- MENU CRUD DES ETUDIANTS ----------
    private static void showStudentMenu() {
        boolean running = true;

        while (running) {
            System.out.println("\n===== GESTION DES ETUDIANTS =====");
            System.out.println("1. Ajouter un etudiant");
            System.out.println("2. Afficher tous les etudiants");
            System.out.println("3. Rechercher un etudiant par id");
            System.out.println("4. Modifier un etudiant");
            System.out.println("5. Supprimer un etudiant");
            System.out.println("6. Quitter");
            System.out.print("Choix : ");

            String choice = scanner.nextLine();

            switch (choice) {
                case "1" -> createStudent();
                case "2" -> readAllStudents();
                case "3" -> readStudentById();
                case "4" -> updateStudent();
                case "5" -> deleteStudent();
                case "6" -> running = false;
                default -> System.out.println("Choix invalide, reessayez.");
            }
        }

        System.out.println("Fin du programme. A bientot.");
    }

    // ---------- CREATE ----------
    private static void createStudent() {
        System.out.print("Prenom : ");
        String firstName = scanner.nextLine();
        System.out.print("Nom : ");
        String lastName = scanner.nextLine();
        System.out.print("Email : ");
        String email = scanner.nextLine();
        System.out.print("Cours : ");
        String course = scanner.nextLine();
        System.out.print("Note : ");
        double grade = Double.parseDouble(scanner.nextLine());

        Student student = new Student(firstName, lastName, email, course, grade);
        studentDAO.addStudent(student);
    }

    // ---------- READ (tous) ----------
    private static void readAllStudents() {
        List<Student> students = studentDAO.getAllStudents();

        if (students.isEmpty()) {
            System.out.println("Aucun etudiant enregistre.");
        } else {
            System.out.println("\nListe des etudiants :");
            for (Student student : students) {
                System.out.println(student);
            }
        }
    }

    // ---------- READ (par id) ----------
    private static void readStudentById() {
        System.out.print("Id de l'etudiant : ");
        int id = Integer.parseInt(scanner.nextLine());

        Student student = studentDAO.getStudentById(id);
        if (student != null) {
            System.out.println(student);
        } else {
            System.out.println("Aucun etudiant trouve avec cet id.");
        }
    }

    // ---------- UPDATE ----------
    private static void updateStudent() {
        System.out.print("Id de l'etudiant a modifier : ");
        int id = Integer.parseInt(scanner.nextLine());

        Student existingStudent = studentDAO.getStudentById(id);
        if (existingStudent == null) {
            System.out.println("Aucun etudiant trouve avec cet id.");
            return;
        }

        System.out.print("Nouveau prenom (" + existingStudent.getFirstName() + ") : ");
        String firstName = scanner.nextLine();
        System.out.print("Nouveau nom (" + existingStudent.getLastName() + ") : ");
        String lastName = scanner.nextLine();
        System.out.print("Nouvel email (" + existingStudent.getEmail() + ") : ");
        String email = scanner.nextLine();
        System.out.print("Nouveau cours (" + existingStudent.getCourse() + ") : ");
        String course = scanner.nextLine();
        System.out.print("Nouvelle note (" + existingStudent.getGrade() + ") : ");
        double grade = Double.parseDouble(scanner.nextLine());

        Student updatedStudent = new Student(id, firstName, lastName, email, course, grade);
        studentDAO.updateStudent(updatedStudent);
    }

    // ---------- DELETE ----------
    private static void deleteStudent() {
        System.out.print("Id de l'etudiant a supprimer : ");
        int id = Integer.parseInt(scanner.nextLine());

        studentDAO.deleteStudent(id);
    }
}
