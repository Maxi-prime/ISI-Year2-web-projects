import java.util.Scanner;

public class Main {
    public static boolean estPremier(int n) {
        if (n <= 1) return false;
        for (int i = 2; i <= n/2; i++) {
            if (n % i == 0) return false;
        }
        return true;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("N: ");
        int N = sc.nextInt();
        int[] t = new int[N];
        int count = 0;

        while (count < N) {
            System.out.print("Nombre " + (count + 1) + ": ");
            int nb = sc.nextInt();
            if (estPremier(nb)) {
                t[count] = nb;
                count++;
            } else {
                System.out.println("Pas premier! Reessayez.");
            }
        }

        System.out.print("Nombres premiers: ");
        for (int i = 0; i < N; i++) {
            System.out.print(t[i] + " ");
        }
    }
}