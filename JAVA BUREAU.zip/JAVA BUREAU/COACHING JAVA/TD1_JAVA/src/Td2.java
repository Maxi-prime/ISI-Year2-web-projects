import java.util.Scanner;

public class Td2 {
    public static void main(String[] args) {
        int age1,age2;

        Scanner sc = new Scanner(System.in);

        System.out.println("Saisir AGE 1");
        age1 = sc.nextInt();

        System.out.println("Saisir AGE 2");
        age2 = sc.nextInt();

        if(age1>age2){
            System.out.println(age1 + " est plus grand que " + age2);
        }
        if(age1<age2){
            System.out.println(age2 + " est plus grand que " + age1);
        }
        if(age1 == age2){
            System.out.println(age2 + " est egale à " + age1);
        }

    }
}
