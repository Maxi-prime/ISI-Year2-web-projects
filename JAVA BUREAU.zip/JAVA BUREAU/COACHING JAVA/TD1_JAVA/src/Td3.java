import java.util.Scanner;

public class Td3 {
    public static void main(String[] args) {
        int choice;
        double N1,N2;

        Scanner sc = new Scanner(System.in);

        System.out.println("Saisir NOMBRE 1");
        N1 = sc.nextInt();

        System.out.println("Saisir NOMBRE 2");
        N2 = sc.nextInt();

        System.out.println("=== MENU ===");
        System.out.println("Faites votre choix");
        System.out.println("1_ Addition\n" +
                           "2_ Soustraction\n" +
                           "3_Multiplication\n" +
                           "4_Division");
        choice = sc.nextInt();

        switch (choice) {
            case 1:
                System.out.println(N1 + " + "+ N2 + " = " + (N1 + N2));
                break;
            case 2:
                System.out.println(N1 + " - "+ N2 + " = " + (N1 - N2));
                break;
            case 3:
                System.out.println(N1 + " X "+ N2 + " = " + (N1 * N2));
                break;
            case 4:
                if(N2 == 0){
                    System.out.println("Impossible de diviser par 0");
                    break;
                }else{
                    System.out.println(N1 + " / "+ N2 + " = " + (N1 / N2));
                    break;
                }

            default:
                System.out.println("Veuillez choisir entre 1 - 4");
        }



    }
}
