import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        System.out.println("Hello word ");
        int a,b;
        String nom;

        // INSTANCIATION DE SCANNER
        Scanner sc = new Scanner(System.in);

        // Pour saisir
        // nexint() => Pour les ENTIERS
        // nexline() => CHAINES | STRING
        // nexfloat() => DECIMAUX
        System.out.println("Veuillez saisir un nombre ");
        a = sc.nextInt();
        System.out.println("Veuillez saisir un nombre ");
        b =  sc.nextInt();
        System.out.println("a + b =" + (a+b));
        System.out.println(a + " + "+ b + " = " + (a + b));
        System.out.println("Veuillez saisir un nom ");
        nom = sc.nextLine();
        System.out.println("Nom : "+ nom );
    }
}
