package models;

public class TacheUrgente extends Tache {
    public TacheUrgente(int id, String titre, String libelle, String statut) {
        super(id, titre, libelle, statut);
    }

    @Override
    public void afficherDetails() {
        System.out.println("[Priorite: URGENTE !!!] ID: " + id + " | Titre: " + titre +
                " | Libellé: " + libelle + " | Statut: " + statut);
    }
}