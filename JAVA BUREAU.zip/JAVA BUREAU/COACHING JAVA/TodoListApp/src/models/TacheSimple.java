package models;

public class TacheSimple extends Tache {
    public TacheSimple(int id, String titre, String libelle, String statut) {
        super(id, titre, libelle, statut);
    }

    @Override
    public void afficherDetails() {
        System.out.println("[Priorite: SIMPLE] ID: " + id + " | Titre: " + titre +
                " | Libellé: " + libelle + " | Statut: " + statut);
    }
}