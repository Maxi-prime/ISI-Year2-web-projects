package models;

public abstract class Tache {
    protected int id;
    protected String titre;
    protected String libelle;
    protected String statut; // "à faire", "en cours", "fait"

    public Tache(int id, String titre, String libelle, String statut) {
        this.id = id;
        this.titre = titre;
        this.libelle = libelle;
        this.statut = statut;
    }

    // Méthode abstraite à implémenter
    public abstract void afficherDetails();

    // Getters et Setters
    public int getId() { return id; }
    public void setStatut(String statut) { this.statut = statut; }
    public String getTitre() { return titre; }
    public void setTitre(String titre) { this.titre = titre; }
    public void setLibelle(String libelle) { this.libelle = libelle; }
}