package services;
import models.Tache;
import java.util.List;

public interface TacheService {
    void ajouterTache(Tache tache);        // Create
    List<Tache> afficherTaches();          // Read
    void modifierTache(int id, String nouveauTitre, String nouveauLibelle, String nouveauStatut); // Update
    void supprimerTache(int id);           // Delete
    Tache trouverTacheParId(int id);
}



