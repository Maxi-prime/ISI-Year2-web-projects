import models.*;
import impl.GestionTache;
import services.TacheService;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        TacheService service = new GestionTache();
        Scanner sc = new Scanner(System.in);
        int choix, id = 1;

        do {
            System.out.println("\n** ===== MENU TODO LIST ===== **");
            System.out.println("1- Ajouter");
            System.out.println("2- Afficher");
            System.out.println("3- Modifier");
            System.out.println("4- Supprimer");
            System.out.println("0- Quitter");
            System.out.print("Choix : ");
            choix = sc.nextInt();
            sc.nextLine(); // vider le buffer

            switch (choix) {
                case 1:
                    System.out.print("Titre: ");
                    String titre = sc.nextLine();
                    System.out.print("Libellé: ");
                    String libelle = sc.nextLine();
                    System.out.print("Type 1-Simple 2-Urgente: ");
                    int type = sc.nextInt();
                    sc.nextLine();

                    Tache nouvelleTache;
                    if (type == 2) {
                        nouvelleTache = new TacheUrgente(id++, titre, libelle, "à faire");
                    } else {
                        nouvelleTache = new TacheSimple(id++, titre, libelle, "à faire");
                    }
                    service.ajouterTache(nouvelleTache);
                    break;

                case 2:
                    System.out.println("\n--- LISTE DES TÂCHES ---");
                    if (service.afficherTaches().isEmpty()) {
                        System.out.println("Aucune tâche.");
                    } else {
                        for (Tache t : service.afficherTaches()) {
                            t.afficherDetails();
                        }
                    }
                    break;

                case 3:
                    System.out.print("ID de la tâche à modifier: ");
                    int idModif = sc.nextInt(); sc.nextLine();
                    System.out.print("Nouveau titre: ");
                    String nTitre = sc.nextLine();
                    System.out.print("Nouveau libellé: ");
                    String nLibelle = sc.nextLine();
                    System.out.print("Nouveau statut [à faire/en cours/fait]: ");
                    String nStatut = sc.nextLine();
                    service.modifierTache(idModif, nTitre, nLibelle, nStatut);
                    break;

                case 4:
                    System.out.print("ID de la tâche à supprimer: ");
                    int idSupp = sc.nextInt();
                    service.supprimerTache(idSupp);
                    break;
            }
        } while (choix != 0);

        System.out.println("À bientôt boss !");
        sc.close();
    }
}

