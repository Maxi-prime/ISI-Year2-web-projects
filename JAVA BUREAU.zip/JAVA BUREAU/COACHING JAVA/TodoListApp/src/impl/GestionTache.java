package impl;
import models.Tache;
import services.TacheService;
import java.util.ArrayList;
import java.util.List;

public class GestionTache implements TacheService {
    private List<Tache> listeTaches = new ArrayList<>();

    @Override
    public void ajouterTache(Tache tache) {
        listeTaches.add(tache);
        System.out.println("Tâche ajoutée avec succès !");
    }

    @Override
    public List<Tache> afficherTaches() {
        return listeTaches;
    }

    @Override
    public Tache trouverTacheParId(int id) {
        for (Tache t : listeTaches) {
            if (t.getId() == id) return t;
        }
        return null;
    }

    @Override
    public void modifierTache(int id, String nouveauTitre, String nouveauLibelle, String nouveauStatut) {
        Tache t = trouverTacheParId(id);
        if (t != null) {
            t.setTitre(nouveauTitre);
            t.setLibelle(nouveauLibelle);
            t.setStatut(nouveauStatut);
            System.out.println("Tâche modifiée !");
        } else {
            System.out.println("Tâche introuvable avec l'ID: " + id);
        }
    }

    @Override
    public void supprimerTache(int id) {
        Tache t = trouverTacheParId(id);
        if (t != null) {
            listeTaches.remove(t);
            System.out.println("Tâche supprimée !");
        } else {
            System.out.println("Tâche introuvable avec l'ID: " + id);
        }
    }
}