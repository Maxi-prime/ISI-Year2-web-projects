import java.util.*;

public class TransportService {
    HashMap<String, Abonnement> abonnements = new HashMap<>();
    HashMap<String, Usager> usagers = new HashMap<>();
    HashMap<String, HashSet<Abonnement>> souscriptions = new HashMap<>();

    // Abonnements
    public void ajouterAbonnement(Abonnement ab) {
        if (abonnements.containsKey(ab.code)) throw new IllegalArgumentException("Code existe");
        abonnements.put(ab.code, ab);
    }

    public Abonnement rechercherParCode(String code) {
        return abonnements.get(code);
    }

    public List<Abonnement> rechercherParType(String type) {
        List<Abonnement> result = new ArrayList<>();
        for (Abonnement ab : abonnements.values()) {
            if (ab.getType().equalsIgnoreCase(type)) result.add(ab);
        }
        return result;
    }

    public double calculerPrixMoyen() {
        if (abonnements.isEmpty()) return 0;
        double total = 0;
        for (Abonnement ab : abonnements.values()) total += ab.getPrix();
        return total / abonnements.size();
    }

    public List<Abonnement> trierParPrixAsc() {
        List<Abonnement> list = new ArrayList<>(abonnements.values());
        Collections.sort(list, Comparator.comparingDouble(Abonnement::getPrix));
        return list;
    }

    // Usagers
    public void ajouterUsager(Usager u) {
        if (usagers.containsKey(u.numerold)) throw new IllegalArgumentException("ID existe");
        usagers.put(u.numerold, u);
    }

    public Usager rechercherUsager(String id) {
        return usagers.get(id);
    }

    public List<Usager> rechercherParNom(String mot) {
        List<Usager> result = new ArrayList<>();
        for (Usager u : usagers.values()) {
            if (u.getNom().toLowerCase().contains(mot.toLowerCase())) result.add(u);
        }
        return result;
    }

    public Set<String> listerEmails() {
        Set<String> emails = new HashSet<>();
        for (Usager u : usagers.values()) emails.add(u.email);
        return emails;
    }

    // Souscriptions
    public void souscrire(String idUsager, String codeAbonnement) throws Exception {
        Usager u = usagers.get(idUsager);
        if (u == null) throw new Exception("Usager inexistant");

        Abonnement ab = abonnements.get(codeAbonnement);
        if (ab == null) throw new Exception("Abonnement inexistant");

        HashSet<Abonnement> liste = souscriptions.get(idUsager);
        if (liste == null) {
            liste = new HashSet<>();
            souscriptions.put(idUsager, liste);
        }

        if (liste.size() >= 5) throw new Exception("Limite 5 abonnements");
        if (liste.contains(ab)) throw new Exception("Deja souscrit");

        liste.add(ab);
        System.out.println("Souscription OK");
    }

    public List<Abonnement> abonnementsUsager(String idUsager) {
        HashSet<Abonnement> liste = souscriptions.get(idUsager);
        if (liste == null) return new ArrayList<>();
        return new ArrayList<>(liste);
    }

    public int nombreTotalSouscriptions() {
        int total = 0;
        for (HashSet<Abonnement> set : souscriptions.values()) total += set.size();
        return total;
    }

    public double totalRevenuActuel() {
        double total = 0;
        for (HashSet<Abonnement> set : souscriptions.values()) {
            for (Abonnement ab : set) total += ab.getPrix();
        }
        return total;
    }

    // Affichages
    public void listerAbonnements() {
        for (Abonnement ab : abonnements.values()) System.out.println(ab);
    }

    public void listerUsagers() {
        for (Usager u : usagers.values()) System.out.println(u);
    }
}