public class Usager {
    String numerold;
    String nom;
    String email;
    int age;

    public Usager(String numerold, String nom, String email, int age) {
        if (numerold.isEmpty()) throw new IllegalArgumentException("ID non vide");
        if (nom.length() < 2) throw new IllegalArgumentException("Nom trop court");
        if (!email.contains("@")) throw new IllegalArgumentException("Email invalide");
        if (age < 16) throw new IllegalArgumentException("Age >= 16");
        this.numerold = numerold;
        this.nom = nom;
        this.email = email;
        this.age = age;
    }

    public String getNumerold() { return numerold; }
    public String getNom() { return nom; }
    public String getEmail() { return email; }

    public String toString() {
        return numerold + " - " + nom + " - " + email + " - " + age + " ans";
    }
}