import java.util.Scanner;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        TransportService ts = new TransportService();
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n=== Gestion Abonnements Transport ===");
            System.out.println("1 Ajouter abonnement | 2 Ajouter usager | 3 Souscrire");
            System.out.println("4 Abonnements d'un usager | 5 Lister usagers | 6 Lister abonnements");
            System.out.println("7 Rechercher par type | 8 Prix moyen | 9 Total revenus | 10 Quitter");
            System.out.print("Choix: ");

            int choix = sc.nextInt(); sc.nextLine();

            try {
                switch (choix) {
                    case 1:
                        System.out.print("Type (Mensuel/Annuel/Etudiant): ");
                        String type = sc.nextLine();
                        System.out.print("Code: ");
                        String code = sc.nextLine();
                        System.out.print("Prix: ");
                        double prix = sc.nextDouble(); sc.nextLine();

                        if (type.equalsIgnoreCase("Mensuel")) {
                            ts.ajouterAbonnement(new AbonnementMensuel(code, prix));
                        } else if (type.equalsIgnoreCase("Annuel")) {
                            ts.ajouterAbonnement(new AbonnementAnnuel(code, prix));
                        } else if (type.equalsIgnoreCase("Etudiant")) {
                            System.out.print("Remise (0-50%): ");
                            double remise = sc.nextDouble(); sc.nextLine();
                            ts.ajouterAbonnement(new AbonnementEtudiant(code, prix, remise));
                        }
                        System.out.println("Ajoute !");
                        break;

                    case 2:
                        System.out.print("ID: ");
                        String id = sc.nextLine();
                        System.out.print("Nom: ");
                        String nom = sc.nextLine();
                        System.out.print("Email: ");
                        String email = sc.nextLine();
                        System.out.print("Age: ");
                        int age = sc.nextInt(); sc.nextLine();
                        ts.ajouterUsager(new Usager(id, nom, email, age));
                        System.out.println("Ajoute !");
                        break;

                    case 3:
                        System.out.print("ID usager: ");
                        String uid = sc.nextLine();
                        System.out.print("Code abonnement: ");
                        String ccode = sc.nextLine();
                        ts.souscrire(uid, ccode);
                        break;

                    case 4:
                        System.out.print("ID usager: ");
                        String uid2 = sc.nextLine();
                        List<Abonnement> list = ts.abonnementsUsager(uid2);
                        if (list.isEmpty()) System.out.println("Aucun abonnement");
                        else for (Abonnement ab : list) System.out.println(ab);
                        break;

                    case 5: ts.listerUsagers(); break;
                    case 6: ts.listerAbonnements(); break;
                    case 7:
                        System.out.print("Type: ");
                        List<Abonnement> result = ts.rechercherParType(sc.nextLine());
                        if (result.isEmpty()) System.out.println("Aucun");
                        else for (Abonnement ab : result) System.out.println(ab);
                        break;
                    case 8:
                        System.out.println("Prix moyen: " + ts.calculerPrixMoyen() + "€");
                        break;
                    case 9:
                        System.out.println("Total revenus: " + ts.totalRevenuActuel() + "€");
                        System.out.println("Nombre total souscriptions: " + ts.nombreTotalSouscriptions());
                        break;
                    case 10:
                        System.out.println("Au revoir !");
                        return;
                    default:
                        System.out.println("Choix invalide");
                }
            } catch (Exception e) {
                System.out.println("Erreur: " + e.getMessage());
            }
        }
    }
}