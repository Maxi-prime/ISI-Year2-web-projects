public abstract class Abonnement {
    String code;
    double prix;
    int dureeJours;

    public Abonnement(String code, double prix, int dureeJours) {
        if (code.isEmpty()) throw new IllegalArgumentException("Code non vide");
        if (prix <= 0) throw new IllegalArgumentException("Prix > 0");
        if (dureeJours < 7) throw new IllegalArgumentException("Duree >= 7");
        this.code = code;
        this.prix = prix;
        this.dureeJours = dureeJours;
    }

    public abstract String getType();

    public String getCode() { return code; }
    public double getPrix() { return prix; }

    public String toString() {
        return code + " - " + getType() + " - " + prix + "€ - " + dureeJours + " jours";
    }
}

class AbonnementMensuel extends Abonnement {
    public AbonnementMensuel(String code, double prix) {
        super(code, prix, 30);
    }
    public String getType() { return "Mensuel"; }
}

class AbonnementAnnuel extends Abonnement {
    public AbonnementAnnuel(String code, double prix) {
        super(code, prix, 365);
    }
    public String getType() { return "Annuel"; }
}

class AbonnementEtudiant extends Abonnement {
    double remise;
    public AbonnementEtudiant(String code, double prix, double remise) {
        super(code, prix, 30);
        if (remise < 0 || remise > 50) throw new IllegalArgumentException("Remise 0-50%");
        this.remise = remise;
    }
    public double getPrix() { return prix * (1 - remise/100); }
    public String getType() { return "Etudiant"; }
    public String toString() {
        return code + " - Etudiant - " + getPrix() + "€ (remise " + remise + "%) - 30 jours";
    }
}