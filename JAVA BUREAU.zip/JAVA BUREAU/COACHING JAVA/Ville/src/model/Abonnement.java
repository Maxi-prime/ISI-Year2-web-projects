package model;

import java.util.Objects;

public abstract class Abonnement {
    private String code;
    private double prix;
    private int dureeJours;

    public Abonnement(String code, double prix, int dureeJours) {
        setCode(code);
        setPrix(prix);
        setDureeJours(dureeJours);
    }

    public String getCode() { return code; }
    public double getPrix() { return prix; }
    public int getDureeJours() { return dureeJours; }

    public void setCode(String code) {
        if (code == null || code.trim().isEmpty()) {
            throw new IllegalArgumentException("Le code ne peut pas etre vide");
        }
        this.code = code;
    }

    public void setPrix(double prix) {
        if (prix <= 0) {
            throw new IllegalArgumentException("Le prix doit être > 0");
        }
        this.prix = prix;
    }

    public void setDureeJours(int dureeJours) {
        if (dureeJours < 7) {
            throw new IllegalArgumentException("La durée doit être ≥ 7 jours");
        }
        this.dureeJours = dureeJours;
    }

    public abstract String getType();

    @Override
    public String toString() {
        return String.format("[%s] %s - %.2f€ (%d jours)", getType(), code, prix, dureeJours);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Abonnement that = (Abonnement) o;
        return Objects.equals(code, that.code);
    }

    @Override
    public int hashCode() {
        return Objects.hash(code);
    }
}
