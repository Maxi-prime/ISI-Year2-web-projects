package model;

public class AbonnementAnnuel extends Abonnement {
    public AbonnementAnnuel(String code, double prix) {
        super(code, prix, 365);
    }

    @Override
    public String getType() {
        return "Annuel";
    }
}


