package model;

public class AbonnementPremium {
    public AbonnementPremium() {
    }
}
