package model;

import java.util.Objects;

public class Usager {
    private String numeroId;
    private String nom;
    private String email;
    private int age;

    public Usager(String numeroId, String nom, String email, int age) {
        setNumeroId(numeroId);
        setNom(nom);
        setEmail(email);
        setAge(age);
    }

    public String getNumeroId() { return numeroId; }
    public String getNom() { return nom; }
    public String getEmail() { return email; }
    public int getAge() { return age; }

    public void setNumeroId(String numeroId) {
        if (numeroId == null || numeroId.trim().isEmpty()) {
            throw new IllegalArgumentException("L'ID ne peut pas être vide");
        }
        this.numeroId = numeroId;
    }

    public void setNom(String nom) {
        if (nom == null || nom.length() < 2) {
            throw new IllegalArgumentException("Le nom doit contenir au moins 2 caractères");
        }
        this.nom = nom;
    }

    public void setEmail(String email) {
        if (email == null || !email.contains("@")) {
            throw new IllegalArgumentException("L'email doit contenir @");
        }
        this.email = email;
    }

    public void setAge(int age) {
        if (age < 16) {
            throw new IllegalArgumentException("L'âge doit être ≥ 16 ans");
        }
        this.age = age;
    }


}