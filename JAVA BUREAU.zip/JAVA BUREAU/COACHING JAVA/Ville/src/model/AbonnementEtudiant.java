package model;

public class AbonnementEtudiant {
}
