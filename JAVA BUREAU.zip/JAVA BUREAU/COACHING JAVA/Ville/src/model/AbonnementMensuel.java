package model;

public class AbonnementMensuel extends Abonnement {
    public AbonnementMensuel(String code, double prix) {
        super(code, prix, 30);
    }

    @Override
    public String getType() {
        return "Mensuel";
    }
}
