

public abstract class Ressource {
    String reference;
    String titre;
    double prix;
    int dureeEmprunt;

    public Ressource(String reference, String titre, double prix, int dureeEmprunt) {
        if (reference.isEmpty()) throw new IllegalArgumentException("Reference non vide");
        if (titre.length() < 3) throw new IllegalArgumentException("Titre trop court");
        if (prix <= 0) throw new IllegalArgumentException("Prix > 0");
        if (dureeEmprunt < 1) throw new IllegalArgumentException("Duree >= 1");
        this.reference = reference;
        this.titre = titre;
        this.prix = prix;
        this.dureeEmprunt = dureeEmprunt;
    }

    public abstract String getCategorie();

    public String getReference() { return reference; }
    public double getPrix() { return prix; }

    public String toString() {
        return reference + " - " + titre + " - " + prix + "€";
    }
}

class Livre extends Ressource {
    String auteur;
    public Livre(String ref, String titre, double prix, String auteur) {
        super(ref, titre, prix, 14);
        if (auteur.isEmpty()) throw new IllegalArgumentException("Auteur requis");
        this.auteur = auteur;
    }
    public String getCategorie() { return "Livre"; }
    public String toString() { return super.toString() + " - " + auteur; }
}

class Magazine extends Ressource {
    int numero;
    public Magazine(String ref, String titre, double prix, int numero) {
        super(ref, titre, prix, 7);
        if (numero <= 0) throw new IllegalArgumentException("Numero > 0");
        this.numero = numero;
    }
    public String getCategorie() { return "Magazine"; }
    public String toString() { return super.toString() + " - N°" + numero; }
}

class Ebook extends Ressource {
    double taille;
    public Ebook(String ref, String titre, double prix, double taille) {
        super(ref, titre, prix, 30);
        if (taille <= 0) throw new IllegalArgumentException("Taille > 0");
        this.taille = taille;
    }
    public String getCategorie() { return "Ebook"; }
    public String toString() { return super.toString() + " - " + taille + "Mo"; }
}