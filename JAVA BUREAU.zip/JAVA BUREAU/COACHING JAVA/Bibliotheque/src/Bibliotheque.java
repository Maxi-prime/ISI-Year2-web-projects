
import java.util.*;

public class Bibliotheque {
    HashMap<String, Ressource> ressources = new HashMap<>();
    HashMap<String, Lecteur> lecteurs = new HashMap<>();
    HashMap<String, HashSet<Ressource>> emprunts = new HashMap<>();

    public void ajouterRessource(Ressource r) {
        if (ressources.containsKey(r.reference)) throw new IllegalArgumentException("Reference existe");
        ressources.put(r.reference, r);
    }

    public void ajouterLecteur(Lecteur l) {
        if (lecteurs.containsKey(l.numeroCarte)) throw new IllegalArgumentException("Lecteur existe");
        lecteurs.put(l.numeroCarte, l);
    }

    public void emprunter(String numCarte, String refRessource) throws Exception {
        Lecteur l = lecteurs.get(numCarte);
        if (l == null) throw new Exception("Lecteur inexistant");

        Ressource r = ressources.get(refRessource);
        if (r == null) throw new Exception("Ressource inexistante");

        HashSet<Ressource> mesEmprunts = emprunts.get(numCarte);
        if (mesEmprunts == null) {
            mesEmprunts = new HashSet<>();
            emprunts.put(numCarte, mesEmprunts);
        }

        if (mesEmprunts.size() >= 4) throw new Exception("Limite 4 emprunts");
        if (mesEmprunts.contains(r)) throw new Exception("Deja emprunte");

        mesEmprunts.add(r);
        System.out.println("Emprunt OK");
    }

    public void ressourcesLecteur(String numCarte) {
        HashSet<Ressource> list = emprunts.get(numCarte);
        if (list == null || list.isEmpty()) {
            System.out.println("Aucun emprunt");
        } else {
            for (Ressource r : list) System.out.println(r);
        }
    }

    public void listerRessources() {
        for (Ressource r : ressources.values()) System.out.println(r);
    }

    public void listerLecteurs() {
        for (Lecteur l : lecteurs.values()) System.out.println(l);
    }

    public void rechercherParCategorie(String categorie) {
        for (Ressource r : ressources.values()) {
            if (r.getCategorie().equalsIgnoreCase(categorie)) System.out.println(r);
        }
    }

    public void prixMoyen() {
        if (ressources.isEmpty()) return;
        double total = 0;
        for (Ressource r : ressources.values()) total += r.prix;
        System.out.println("Prix moyen: " + (total / ressources.size()));
    }

    public void valeurTotaleEmpruntee() {
        double total = 0;
        for (HashSet<Ressource> set : emprunts.values()) {
            for (Ressource r : set) total += r.prix;
        }
        System.out.println("Valeur totale empruntee: " + total);
    }
}