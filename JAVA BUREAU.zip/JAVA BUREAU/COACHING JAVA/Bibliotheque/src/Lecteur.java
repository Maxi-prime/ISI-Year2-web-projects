

public class Lecteur {
    String numeroCarte;
    String nom;
    String email;
    int age;

    public Lecteur(String numeroCarte, String nom, String email, int age) {
        if (numeroCarte.isEmpty()) throw new IllegalArgumentException("Carte requis");
        if (nom.length() < 2) throw new IllegalArgumentException("Nom trop court");
        if (!email.contains("@")) throw new IllegalArgumentException("Email invalide");
        if (age < 12) throw new IllegalArgumentException("Age >= 12");
        this.numeroCarte = numeroCarte;
        this.nom = nom;
        this.email = email;
        this.age = age;
    }

    public String getNumeroCarte() { return numeroCarte; }
    public String getNom() { return nom; }
    public String getEmail() { return email; }

    public String toString() {
        return numeroCarte + " - " + nom + " - " + email;
    }
}