import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Bibliotheque b = new Bibliotheque();
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n1 Ajouter ressource | 2 Ajouter lecteur | 3 Emprunter | 4 Ressources lecteur");
            System.out.println("5 Lister ressources | 6 Lister lecteurs | 7 Rechercher par categorie");
            System.out.println("8 Prix moyen | 9 Valeur empruntee | 10 Quitter");
            System.out.print("Choix: ");

            int choix = sc.nextInt(); sc.nextLine();

            try {
                switch (choix) {
                    case 1:
                        System.out.print("Type (Livre/Magazine/Ebook): ");
                        String type = sc.nextLine();
                        System.out.print("Reference: ");
                        String ref = sc.nextLine();
                        System.out.print("Titre: ");
                        String titre = sc.nextLine();
                        System.out.print("Prix: ");
                        double prix = sc.nextDouble(); sc.nextLine();

                        if (type.equalsIgnoreCase("Livre")) {
                            System.out.print("Auteur: ");
                            b.ajouterRessource(new Livre(ref, titre, prix, sc.nextLine()));
                        } else if (type.equalsIgnoreCase("Magazine")) {
                            System.out.print("Numero: ");
                            b.ajouterRessource(new Magazine(ref, titre, prix, sc.nextInt()));
                            sc.nextLine();
                        } else if (type.equalsIgnoreCase("Ebook")) {
                            System.out.print("Taille Mo: ");
                            b.ajouterRessource(new Ebook(ref, titre, prix, sc.nextDouble()));
                            sc.nextLine();
                        }
                        System.out.println("Ajoute !");
                        break;

                    case 2:
                        System.out.print("Numero carte: ");
                        String num = sc.nextLine();
                        System.out.print("Nom: ");
                        String nom = sc.nextLine();
                        System.out.print("Email: ");
                        String email = sc.nextLine();
                        System.out.print("Age: ");
                        b.ajouterLecteur(new Lecteur(num, nom, email, sc.nextInt()));
                        sc.nextLine();
                        System.out.println("Ajoute !");

                        System.out.println("===== Gestion Admin  =====");
                        System.out.println("1. Ajouter un plat");
                        System.out.println("2. Modifier un plat");
                        System.out.println("3. Supprimer un plat");
                        System.out.println("4. Afficher les plats disponibles");
                        System.out.println("5. Retour au menu principal");
                        System.out.print("Entrez votre choix : ");
                        break;

                    case 3:
                        System.out.print("Numero carte: ");
                        String nc = sc.nextLine();
                        System.out.print("Reference ressource: ");
                        b.emprunter(nc, sc.nextLine());
                        break;

                    case 4:
                        System.out.print("Numero carte: ");
                        b.ressourcesLecteur(sc.nextLine());
                        break;

                    case 5: b.listerRessources(); break;
                    case 6: b.listerLecteurs(); break;
                    case 7:
                        System.out.print("Categorie: ");
                        b.rechercherParCategorie(sc.nextLine());
                        break;
                    case 8: b.prixMoyen(); break;
                    case 9: b.valeurTotaleEmpruntee(); break;
                    case 10: System.out.println("Au revoir !"); return;
                }
            } catch (Exception e) {
                System.out.println("Erreur: " + e.getMessage());
            }
        }
    }
}