public class Produit {
    private int id;
    private String libelle;
    private int quantite;
    private double prixUnitaire;
    private Date datePeremption;

    // Constructeur
    public Produit(int id, String libelle, int quantite, double prixUnitaire, Date datePeremption) {
        this.id = id;
        this.libelle = libelle;
        this.quantite = quantite;
        this.prixUnitaire = prixUnitaire;
        this.datePeremption = datePeremption;
    }

    // Getters
    public int getId() {
        return id;
    }

    public String getLibelle() {
        return libelle;
    }

    public int getQuantite() {
        return quantite;
    }

    public double getPrixUnitaire() {
        return prixUnitaire;
    }

    public Date getDatePeremption() {
        return datePeremption;
    }

    // Setters
    public void setId(int id) {
        this.id = id;
    }

    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }

    public void setQuantite(int quantite) {
        this.quantite = quantite;
    }

    public void setPrixUnitaire(double prixUnitaire) {
        this.prixUnitaire = prixUnitaire;
    }

    public void setDatePeremption(Date datePeremption) {
        this.datePeremption = datePeremption;
    }

    @Override
    public String toString() {
        return "ID: " + id +
                " | Libellé: " + libelle +
                " | Quantité: " + quantite +
                " | Prix: " + String.format("%.1f", prixUnitaire) + "FCFA" +
                " | Date péremption: " + datePeremption.toString();
    }
}