import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class Date {
    private int jour;
    private int mois;
    private int annee;

    // Constructeur
    public Date(int jour, int mois, int annee) {
        this.jour = jour;
        this.mois = mois;
        this.annee = annee;
    }

    // Constructeur à partir d'une chaîne
    public Date(String dateStr) {
        String[] parties = dateStr.split("/");
        if (parties.length == 3) {
            this.jour = Integer.parseInt(parties[0]);
            this.mois = Integer.parseInt(parties[1]);
            this.annee = Integer.parseInt(parties[2]);
        }
    }

    // Getters
    public int getJour() {
        return jour;
    }

    public int getMois() {
        return mois;
    }

    public int getAnnee() {
        return annee;
    }

    // Setters
    public void setJour(int jour) {
        this.jour = jour;
    }

    public void setMois(int mois) {
        this.mois = mois;
    }

    public void setAnnee(int annee) {
        this.annee = annee;
    }

    // Convertir en LocalDate pour faciliter les comparaisons
    public LocalDate toLocalDate() {
        return LocalDate.of(annee, mois, jour);
    }

    // Vérifier si la date est valide
    public boolean estValide() {
        try {
            LocalDate.of(annee, mois, jour);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public String toString() {
        return String.format("%02d/%02d/%04d", jour, mois, annee);
    }

    // Méthode statique pour parser une date
    public static Date parseDate(String dateStr) {
        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            LocalDate ld = LocalDate.parse(dateStr, formatter);
            return new Date(ld.getDayOfMonth(), ld.getMonthValue(), ld.getYear());
        } catch (DateTimeParseException e) {
            return null;
        }
    }
}