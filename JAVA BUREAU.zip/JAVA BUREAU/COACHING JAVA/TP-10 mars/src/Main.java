import java.util.Scanner;

public class Main {
    private static Produit[] produits = new Produit[100];
    private static int nombreProduits = 0;
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int choix;

        do {
            afficherMenu();
            choix = lireEntier("Votre choix : ");

            switch(choix) {
                case 1:
                    ajouterProduit();
                    break;
                case 2:
                    afficherTousProduits();
                    break;
                case 3:
                    afficherProduitParId();
                    break;
                case 4:
                    modifierPrix();
                    break;
                case 5:
                    modifierQuantite();
                    break;
                case 6:
                    supprimerProduit();
                    break;
                case 0:
                    System.out.println("Au revoir !");
                    break;
                default:
                    System.out.println("Choix invalide !");
            }

        } while(choix != 0);

        scanner.close();
    }

    private static void afficherMenu() {
        System.out.println("\n=== GESTION DES PRODUITS ===");
        System.out.println("1 - Ajouter un produit");
        System.out.println("2 - Afficher tous les produits");
        System.out.println("3 - Afficher un produit par ID");
        System.out.println("4 - Modifier le prix");
        System.out.println("5 - Modifier la quantité");
        System.out.println("6 - Supprimer un produit");
        System.out.println("0 - Quitter");
    }

    private static void ajouterProduit() {
        if (nombreProduits >= produits.length) {
            System.out.println("Erreur : Tableau plein !");
            return;
        }

        System.out.println("\n--- Ajout d'un produit ---");

        int id = lireEntier("ID : ");

        // Vérifier si l'ID existe déjà
        if (rechercherProduitParId(id) != -1) {
            System.out.println("Erreur : Cet ID existe déjà !");
            return;
        }

        System.out.print("Libellé : ");
        String libelle = scanner.nextLine();

        int quantite = lireEntier("Quantité : ");
        double prix = lireDouble("Prix unitaire : ");

        Date datePeremption = lireDate("Date péremption (jj/mm/aaaa) : ");
        if (datePeremption == null) {
            System.out.println("Date invalide !");
            return;
        }

        Produit produit = new Produit(id, libelle, quantite, prix, datePeremption);
        produits[nombreProduits] = produit;
        nombreProduits++;

        System.out.println("Produit ajouté avec succès !");
    }

    private static void afficherTousProduits() {
        System.out.println("\n--- Liste des produits ---");

        if (nombreProduits == 0) {
            System.out.println("Aucun produit en stock.");
            return;
        }

        for (int i = 0; i < nombreProduits; i++) {
            System.out.println(produits[i]);
        }
    }

    private static void afficherProduitParId() {
        System.out.println("\n--- Recherche par ID ---");
        int id = lireEntier("ID du produit : ");

        int index = rechercherProduitParId(id);

        if (index == -1) {
            System.out.println("Produit non trouvé !");
        } else {
            System.out.println("Produit trouvé :");
            System.out.println(produits[index]);
        }
    }

    private static void modifierPrix() {
        System.out.println("\n--- Modification du prix ---");
        int id = lireEntier("ID du produit : ");

        int index = rechercherProduitParId(id);

        if (index == -1) {
            System.out.println("Produit non trouvé !");
            return;
        }

        System.out.println("Prix actuel : " + String.format("%.2f", produits[index].getPrixUnitaire()) + "€");
        double nouveauPrix = lireDouble("Nouveau prix : ");

        produits[index].setPrixUnitaire(nouveauPrix);
        System.out.println("Prix modifié avec succès !");
    }

    private static void modifierQuantite() {
        System.out.println("\n--- Modification de la quantité ---");
        int id = lireEntier("ID du produit : ");

        int index = rechercherProduitParId(id);

        if (index == -1) {
            System.out.println("Produit non trouvé !");
            return;
        }

        System.out.println("Quantité actuelle : " + produits[index].getQuantite());
        int nouvelleQuantite = lireEntier("Nouvelle quantité : ");

        produits[index].setQuantite(nouvelleQuantite);
        System.out.println("Quantité modifiée avec succès !");
    }

    private static void supprimerProduit() {
        System.out.println("\n--- Suppression d'un produit ---");
        int id = lireEntier("ID du produit à supprimer : ");

        int index = rechercherProduitParId(id);

        if (index == -1) {
            System.out.println("Produit non trouvé !");
            return;
        }

        // Afficher le produit avant suppression
        System.out.println("Produit à supprimer :");
        System.out.println(produits[index]);

        String confirmation = lireString("Confirmer la suppression (o/n) : ");
        if (confirmation.equalsIgnoreCase("o")) {
            // Décaler tous les éléments suivants vers la gauche
            for (int i = index; i < nombreProduits - 1; i++) {
                produits[i] = produits[i + 1];
            }

            produits[nombreProduits - 1] = null;
            nombreProduits--;

            System.out.println("Produit supprimé avec succès !");
        } else {
            System.out.println("Suppression annulée.");
        }
    }

    private static int rechercherProduitParId(int id) {
        for (int i = 0; i < nombreProduits; i++) {
            if (produits[i].getId() == id) {
                return i;
            }
        }
        return -1;
    }

    private static int lireEntier(String message) {
        while (true) {
            try {
                System.out.print(message);
                int valeur = Integer.parseInt(scanner.nextLine());
                return valeur;
            } catch (NumberFormatException e) {
                System.out.println("Veuillez entrer un nombre valide !");
            }
        }
    }

    private static double lireDouble(String message) {
        while (true) {
            try {
                System.out.print(message);
                double valeur = Double.parseDouble(scanner.nextLine());
                return valeur;
            } catch (NumberFormatException e) {
                System.out.println("Veuillez entrer un nombre valide !");
            }
        }
    }

    private static Date lireDate(String message) {
        while (true) {
            System.out.print(message);
            String dateStr = scanner.nextLine();

            Date date = Date.parseDate(dateStr);
            if (date != null && date.estValide()) {
                return date;
            }

            System.out.println("Format de date invalide ! Utilisez jj/mm/aaaa");
        }
    }

    private static String lireString(String message) {
        System.out.print(message);
        return scanner.nextLine();
    }
}