package com.joj.model;

public class Utilisateur {
    private int id;
    private String nomComplet;
    private String login;
    private String motDePasse;
    private String role;
    private String email;
    private int  age;
    private int  Telephone;


    public Utilisateur() {}

    public Utilisateur(int id, String nomComplet, String login, String motDePasse, String role,String email, int age, int Telephone) {
        this.id = id;
        this.nomComplet = nomComplet;
        this.login = login;
        this.motDePasse = motDePasse;
        this.role = role;
        this.email = email;
        this.age = age;
        this.Telephone = Telephone;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getNomComplet() { return nomComplet; }
    public void setNomComplet(String nomComplet) { this.nomComplet = nomComplet; }
    public String getLogin() { return login; }
    public void setLogin(String login) { this.login = login; }
    public String getMotDePasse() { return motDePasse; }
    public void setMotDePasse(String motDePasse) { this.motDePasse = motDePasse; }
    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }
    public int getTelephone() { return Telephone; }
    public void setTelephone(int Telephone) { this.Telephone = Telephone; }
}