package com.joj;

import com.joj.ui.MenuPrincipal;

public class Main {
    public static void main(String[] args) {
        MenuPrincipal menu = new MenuPrincipal();
        menu.demarrer();
    }
}