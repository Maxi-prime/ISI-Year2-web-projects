package Repo;

import Models.Plat;

public interface GestionPlat {
    public void ajouterPlat(Plat p);
    public void modifierPlat(Plat p, int id);
    public void supprimerPlat(Plat p, int id);
    public void afficherPlatsDispo();
}
