package Repo;

import Models.Commande;

public interface MontantTouTCommade {
    void MontantTotalCommande(Commande c);
}
