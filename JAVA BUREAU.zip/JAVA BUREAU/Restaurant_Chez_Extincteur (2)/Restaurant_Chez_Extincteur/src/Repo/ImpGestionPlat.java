package Repo;

import Models.Client;
import Models.Plat;

import java.util.ArrayList;
import java.util.Scanner;

public class ImpGestionPlat implements GestionPlat {
    ArrayList<Plat> plats;
    public ImpGestionPlat() {
        plats = new ArrayList<>();
    }

    @Override
    public void ajouterPlat(Plat p) {
        System.out.print("Entrez le nom du plat : ");
        Scanner sc = new Scanner(System.in);
        String nom = sc.nextLine();
        System.out.println("Entrez le prix du plat : ");
        double prix = sc.nextDouble();
        p = new Plat(plats.size() + 1, nom, prix);
        plats.add(p);
        System.out.println("Plat ajouté avec succès !");
    }

    @Override
    public void modifierPlat(Plat p, int idMod) {
        for (Plat plat : plats) {
            if (plat.getId() == idMod) {
                System.out.print("Entrez le nouveau nom du plat : ");
                Scanner sc = new Scanner(System.in);
                String nom = sc.nextLine();
                System.out.println("Entrez le nouveau prix du plat : ");
                double prix = sc.nextDouble();
                plat.setNom(nom);
                plat.setPrix(prix);
                System.out.println("Plat modifié avec succès !");
            }
        }
    }

    @Override
    public void supprimerPlat(Plat p, int idSup) {
        for (Plat plat : plats) {
            if (plat.getId() == idSup) {
                plats.remove(plat);
                System.out.println("Plat supprimé avec succès !");
            }
        }
    }

    @Override
    public void afficherPlatsDispo() {
        System.out.println("Liste des plats disponibles :");
        for (Plat plat : plats) {
            System.out.println(plat);
        }
    }
}
