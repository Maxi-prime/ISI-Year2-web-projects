package Repo;

import Models.Commande;

import java.util.Map;


public interface GestionCommande {
    void AjouterCommande(Commande c);
    double MontantTotal(String idClient);
    void AfficherCommandes();
    void SupprimerCommande(String idClient);
    Map<String, Commande> getCommandes();

}
