package Repo;

import Models.Client;

public interface GestionClient {
        public void ajouterClient(Models.Client client);
        public void afficherClients();

        java.util.ArrayList<Client> getClients();
}
