package Repo;

import Models.Commande;
import Models.Plat;
import java.util.*;

public class ImpGestionCommande implements GestionCommande {

    // Clé = ID du client, Valeur = Commande
    private Map<String, Commande> commandes = new HashMap<>();

    @Override
    public void AjouterCommande(Commande c) {
        Scanner sc = new Scanner(System.in);
        int nbr;

        do {
            System.out.println("Entrez le nombre de plats à ajouter :");
            nbr = sc.nextInt();
        } while (nbr <= 0);

        sc.nextLine(); // vider le buffer
        for (int i = 1; i <= nbr; i++) {
            System.out.println("--- Plat " + i + " ---");
            System.out.println("Nom du plat :");
            String nom = sc.nextLine();
            System.out.println("Prix du plat :");
            double prix = sc.nextDouble();
            sc.nextLine();
            c.getPlats().add(new Plat(nom, prix));
        }

        // Clé = idClient
        commandes.put(c.getIdClient(), c);
        System.out.println("Commande du client [" + c.getIdClient() + "] ajoutée !");
    }

    @Override
    public double MontantTotal(String idClient) {
        Commande c = commandes.get(idClient);
        if (c == null) {
            System.out.println("Aucune commande pour le client : " + idClient);
            return 0;
        }
        double total = 0;
        for (Plat p : c.getPlats()) {
            total += p.getPrix();
        }
        return total;
    }

    @Override
    public void AfficherCommandes() {
        if (commandes.isEmpty()) {
            System.out.println("Aucune commande enregistrée.");
            return;
        }
        for (Map.Entry<String, Commande> entry : commandes.entrySet()) {
            System.out.println("==============================");
            System.out.println("Client ID : " + entry.getKey());
            System.out.println("Commande : " + entry.getValue());
            System.out.println("Total : " + MontantTotal(entry.getKey()) + " DA");
        }
        System.out.println("==============================");
    }

    @Override
    public void SupprimerCommande(String idClient) {
        if (commandes.remove(idClient) != null) {
            System.out.println("Commande du client [" + idClient + "] supprimée.");
        } else {
            System.out.println("Client introuvable : " + idClient);
        }
    }

    @Override
    public Map<String, Commande> getCommandes() {
        return commandes;
    }
}
