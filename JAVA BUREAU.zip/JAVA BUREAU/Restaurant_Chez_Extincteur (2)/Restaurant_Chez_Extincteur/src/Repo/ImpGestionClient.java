package Repo;

import Models.Client;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ImpGestionClient implements GestionClient {

    ArrayList<Client> clients;
    public ImpGestionClient() {
        clients = new ArrayList<>();
    }

    @Override
    public void ajouterClient(Client client) {
        System.out.print("Entrez le nom du client : ");
        Scanner sc = new Scanner(System.in);
        String nom = sc.nextLine();
        System.out.println("Entre le prenom du client : ");
        String prenom = sc.nextLine();
        System.out.println("Entrez le numero de telephone : ");
        String telephone = sc.nextLine();
        System.out.print("Entrez l'email du client : ");
        String email = sc.nextLine();
        System.out.println("Entrez l'adresse du client : ");
        String adresse = sc.nextLine();
        client = new Client(nom, prenom, telephone, email, adresse);
        clients.add(client);
        System.out.println("Client ajouté avec succès !");
    }

    @Override
    public void afficherClients() {
        System.out.println("Liste des clients :");
        for (Client client : clients) {
            System.out.println(client);
        }
    }

    @Override
    public ArrayList<Client> getClients() {
        return clients;
    }
}