package Repo;
import Models.Plat;
import Models.Commande;

public class ImpMontantTT{
   /* @Override
    public static void MontantTotal(Commande c) {
        double montantTotal = 0;
        for (int i = 0; i < c.getPlat().size(); i++) {
            montantTotal += c.getPlat().get(i).getPrix() * c.getQuantite();
        }
        System.out.println("Le montant total de la commande est : " + montantTotal);
    }*/
}