import Models.Client;
import Models.Plat;
import Models.Commande;
import Repo.ImpGestionClient;
import Repo.ImpGestionCommande;
import Repo.ImpGestionPlat;
import Repo.ImpMontantTT;

import java.util.ArrayList;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        ArrayList<Client> clients;
        clients = new ArrayList<>();

        ImpGestionClient ImpGestionClient = new ImpGestionClient();
        ImpGestionPlat ImpGestionPlat = new ImpGestionPlat();
        ImpGestionCommande ImpGestionCommande = new ImpGestionCommande();

        Scanner sc = new Scanner(System.in);
        int choix;
        int ch,c1,c2;
        do{
            System.out.println("===== Menu =====");
            System.out.println("1. Gérer les clients");
            System.out.println("2. Gérer les plats");
            System.out.println("3. Gérer les commandes");
            System.out.println("4. Quitter");
            System.out.print("Entrez votre choix : ");
            choix = sc.nextInt();
            System.out.println();
            switch (choix) {
                case 1:
                    do{
                        System.out.println("===== Gérer les clients =====");
                        System.out.println("1. Ajouter un client");
                        System.out.println("2. Afficher les clients");
                        System.out.println("3. Retour au menu principal");
                        System.out.print("Entrez votre choix : ");
                        ch = sc.nextInt();
                        System.out.println();
                        switch (ch) {
                            case 1:
                                ImpGestionClient.ajouterClient(new Client());
                                break;
                            case 2:
                                ImpGestionClient.afficherClients();
                                break;
                        }
                    }while (ch != 3);
                    break;
                case 2:
                    do{
                        System.out.println("===== Gérer les plats =====");
                        System.out.println("1. Ajouter un plat");
                        System.out.println("2. Modifier un plat");
                        System.out.println("3. Supprimer un plat");
                        System.out.println("4. Afficher les plats disponibles");
                        System.out.println("5. Retour au menu principal");
                        System.out.print("Entrez votre choix : ");
                        c1 = sc.nextInt();
                        System.out.println();
                        switch (c1) {
                            case 1:
                                ImpGestionPlat.ajouterPlat(new Plat());
                                break;
                            case 2:
                                System.out.println("Entrez l'ID du plat à modifier : ");
                                int idMod = sc.nextInt();
                                ImpGestionPlat.modifierPlat(new Plat(), idMod);
                                break;
                            case 3:
                                System.out.println("Entrez l'ID du plat à supprimer : ");
                                int idSup = sc.nextInt();
                                ImpGestionPlat.supprimerPlat(new Plat(), idSup);
                                break;
                            case 4:
                                ImpGestionPlat.afficherPlatsDispo();
                                break;
                        }
                    }while (c1 != 5);
                    break;
                case 3:
                    do{
                        System.out.println("===== Gérer les plats =====");
                        System.out.println("1. Créer une commande");
                        System.out.println("2. Ajouter un ou plusieurs plats à une commande");
                        System.out.println("3. Calculer automatiquement le montant total de la commande");
                        System.out.println("4. Afficher le détail d'une commande");
                        System.out.println("5. Retour au menu principal");
                        System.out.print("Entrez votre choix : ");
                        c2 = sc.nextInt();
                        System.out.println();
                        switch (c2) {
                            case 1:
                                ImpGestionCommande.ajouterCommande(new Commande());
                                break;
                            case 2:
                                ImpGestionCommande.AjouterUnOuPlusieursPlatsAUneCommande(new Commande());
                                break;
                            case 3:
                              /*  ImpMontantTT.MontantTotal(new Commande());*/
                                break;
                            case 4:
                                ImpGestionCommande.AfficherDetailUneCommande();
                                break;
                        }
                    }while (c2 != 5);
                case 4:
                    System.out.println("Au revoir !");
                    break;
                default:
                    System.out.println("Choix invalide. Veuillez réessayer.");
            }
        }while (choix != 4);
    }
}