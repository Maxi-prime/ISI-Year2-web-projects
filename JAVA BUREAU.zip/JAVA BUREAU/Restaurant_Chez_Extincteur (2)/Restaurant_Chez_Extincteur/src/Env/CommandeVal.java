package Env;

public class CommandeVal extends RuntimeException {
    public CommandeVal(String message) {
        super(message);
    }
}
