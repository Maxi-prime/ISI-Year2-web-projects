package Models;

import java.util.ArrayList;
import java.util.List;

public class Commande {
    private String idClient; // ← clé de la Map
    private String nomClient;
    private List<Plat> plats = new ArrayList<>();

    public Commande(String idClient, String nomClient) {
        this.idClient = idClient;
        this.nomClient = nomClient;
    }

    public String getIdClient() { return idClient; }
    public String getNomClient() { return nomClient; }
    public List<Plat> getPlats() { return plats; }

    @Override
    public String toString() {
        return "Client: " + nomClient + " | Plats: " + plats;
    }

}
