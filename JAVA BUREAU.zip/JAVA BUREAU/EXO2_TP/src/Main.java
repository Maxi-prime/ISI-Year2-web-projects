import java.util.Scanner;

public class Main {
    public static void inverser(int[] tableau) {
        int debut = 0;
        int fin = tableau.length - 1;
        while (debut < fin) {
            int temp = tableau[debut];
            tableau[debut] = tableau[fin];
            tableau[fin] = temp;
            debut++;
            fin--;
        }
    }

    public static void trierCroissant(int[] tableau) {
        for (int i = 0; i < tableau.length - 1; i++) {
            for (int j = 0; j < tableau.length - i - 1; j++) {
                if (tableau[j] > tableau[j + 1]) {
                    int temp = tableau[j];
                    tableau[j] = tableau[j + 1];
                    tableau[j + 1] = temp;
                }
            }
        }
    }

    public static void trierDecroissant(int[] tableau) {
        for (int i = 0; i < tableau.length - 1; i++) {
            for (int j = 0; j < tableau.length - i - 1; j++) {
                if (tableau[j] < tableau[j + 1]) {
                    int temp = tableau[j];
                    tableau[j] = tableau[j + 1];
                    tableau[j + 1] = temp;
                }
            }
        }
    }

    public static boolean estPremier(int nombre) {
        if (nombre <= 1) return false;
        for (int i = 2; i <= Math.sqrt(nombre); i++) {
            if (nombre % i == 0) return false;
        }
        return true;
    }

    public static int compterPremiers(int[] tableau) {
        int compteur = 0;
        for (int nombre : tableau) {
            if (estPremier(nombre)) compteur++;
        }
        return compteur;
    }

    public static boolean estParfait(int nombre) {
        if (nombre <= 1) return false;
        int somme = 0;
        for (int i = 1; i <= nombre / 2; i++) {
            if (nombre % i == 0) somme = somme + i;
        }
        return somme == nombre;
    }

    public static int compterParfaits(int[] tableau) {
        int compteur = 0;
        for (int nombre : tableau) {
            if (estParfait(nombre)) compteur++;
        }
        return compteur;
    }

    public static void afficher(int[] tableau) {
        for (int nombre : tableau) {
            System.out.print(nombre + " ");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Entrez N: ");
        int N = scanner.nextInt();
        int[] tableau = new int[N];
        for (int i = 0; i < N; i++) {
            System.out.print("Element " + (i + 1) + ": ");
            tableau[i] = scanner.nextInt();
        }
        System.out.println("Original:");
        afficher(tableau);
        int[] tab1 = tableau.clone();
        inverser(tab1);
        System.out.println("Inverse:");
        afficher(tab1);
        int[] tab2 = tableau.clone();
        trierCroissant(tab2);
        System.out.println("Croissant:");
        afficher(tab2);
        int[] tab3 = tableau.clone();
        trierDecroissant(tab3);
        System.out.println("Decroissant:");
        afficher(tab3);
        System.out.println("Nombres premiers: " + compterPremiers(tableau));
        System.out.println("Nombres parfaits: " + compterParfaits(tableau));
    }
}