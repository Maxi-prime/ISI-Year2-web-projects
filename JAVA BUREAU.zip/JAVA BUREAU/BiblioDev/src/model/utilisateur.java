Package model ;

Public class Utilisateur {
    Private int id ;
    Private String nom, prenom, email, motdepasse ;
    Private String role ;

    Public Utilisateur() {}

    Public Utilisateur(int id, String nom, String prenom, String email, String motdepasse, String role) {
        This.id = id ;
        This.nom = nom ;
        This.prenom = prenom ;
        This.email = email ;
        This.motdepasse = motdepasse ;
        This.role = role ;
    }

    Public int getId() { return id ; }
    Public void setId(int id) { this.id = id ; }
    Public String getNom() { return nom ; }
    Public void setNom(String nom) { this.nom = nom ; }
    Public String getPrenom() { return prenom ; }
    Public void setPrenom(String prenom) { this.prenom = prenom ; }
    Public String getEmail() { return email ; }
    Public void setEmail(String email) { this.email = email ; }
    Public String getMotdepasse() { return motdepasse ; }
    Public void setMotdepasse(String motdepasse) { this.motdepasse = motdepasse ; }
    Public String getRole() { return role ; }
    Public void setRole(String role) { this.role = role ; }
}
