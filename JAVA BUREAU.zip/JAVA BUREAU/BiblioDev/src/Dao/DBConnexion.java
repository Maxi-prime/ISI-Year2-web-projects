Package dao ;
//Import java.sql.Connection ;

Public class DBConnexion {
    Private static final String URL = jdbc
    Private static final String USER ="root" ;
    Private static final String PASSWORD = "" ;

    Public static Connection getConnection() throws SQLException {
        Return DriverManager.getConnection(URL, USER, PASSWORD) ;
    }
}
