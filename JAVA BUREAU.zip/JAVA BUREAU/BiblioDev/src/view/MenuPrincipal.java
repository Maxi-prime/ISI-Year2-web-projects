Package view ;
Import dao.UtilisateurDAO ;
Import model.Utilisateur ;
Import java.util.Scanner ;

Public class MenuPrincipal {
    Private static Scanner sc = new Scanner(System.in) ;
    Private static Utilisateur utilisateurConnecte = null ;
    Private static UtilisateurDAO userDAO = new UtilisateurDAO() ;

    Public static void afficher() {
        Int choix ;
        Do {
            System.out.println("\\n===== MENU PRINCIPAL ====="  ) ;
            If (utilisateurConnecte == null) {
                System.out.println("1. Se Connecter ») ;
                System.out.println("2. Quitter") ;
            } else {
                System.out.println("" Connecté :   + utilisateurConnecte.getPrenom()) ;
                System.out.println("1. Se Déconnecter ») ;
                System.out.println("2. Accéder au menu ") ;
            }
            System.out.print("Choix :  ") ;
            Choix = sc.nextInt() ;
            Sc.nextLine() ;

            If (utilisateurConnecte == null) {
                Switch (choix) {
                    Case 1 : seConnecter() ; break ;
                    Case 2 : System.out.println( "Au revoir") ; break ;
                }
            } else {
                Switch (choix) {
                    Case 1 : seDeconnecter() ; break ;
                    Case 2 : redirigerMenu() ; break ;
                }
            }
        } while (choix != 2 || utilisateurConnecte != null) ;
    }


}