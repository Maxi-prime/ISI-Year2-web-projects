import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        ArrayList<utilisateur> clients;
        utilisateur = new ArrayList<>();


        Scanner sc = new Scanner(System.in);
        int choix;
        int ch,c1,c2;
        do{
            System.out.println("===== Menu =====");
            System.out.println("1. Se connecter");
            System.out.println("2. Deconnecter");
            System.out.println("3. Quitter");

            System.out.print("Entrez votre choix : ");
            choix = sc.nextInt();
            System.out.println();
            switch (choix) {
                case 1:
                    do{
                        System.out.println("===== Menu Admin =====");
                        System.out.println("1. Ajouter un utilisateur");
                        System.out.println("2. Lister les utilisateurs");
                        System.out.println("3. Rechercher un utilisateur");
                        System.out.println("3. Ajouter un livre");
                        System.out.println("3. Lister les livres");
                        System.out.print("Entrez votre choix : ");
                        ch = sc.nextInt();
                        System.out.println();
                        switch (ch) {
                            case 1:

                                break;
                            case 2:

                                break;
                        }
                    }while (ch != 3);
                    break;
                case 2:
                    do{
                        System.out.println("===== Menu Gestionnaire =====");
                        System.out.println("1. Enregistrer un Emprunt");
                        System.out.println("2. Afficher un Emprunts");
                        System.out.println("3. Retourner un livre");
                        System.out.println("5. Quitter");
                        System.out.print("Entrez votre choix : ");
                        c1 = sc.nextInt();
                        System.out.println();
                        switch (c1) {
                            case 1:

                                break;
                            case 2:
                                System.out.println("Entrez l'ID du plat à modifier : ");
                                int idMod = sc.nextInt();

                                break;
                            case 3:
                                System.out.println("Entrez l'ID du plat à supprimer : ");
                                int idSup = sc.nextInt();

                                break;
                            case 4:

                                break;
                        }
                    }while (c1 != 5);
                    break;
                case 3:
                    System.out.println("Au revoir !");
                    break;
                default:
                    System.out.println("Choix invalide. Veuillez réessayer.");
            }
        }while (choix != 3);
    }
}























