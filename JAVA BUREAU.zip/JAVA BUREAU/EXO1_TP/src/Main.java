import java.util.Scanner;

public class Main {
    public static void calculerMoyenne(int[] notes) {
        int somme = 0;
        for (int i = 0; i < notes.length; i++) {
            somme = somme + notes[i];
        }
        double moyenne = (double) somme / notes.length;
        System.out.println("Moyenne : " + moyenne);
        if (moyenne >= 16) {
            System.out.println("Tres bien");
        } else if (moyenne >= 14) {
            System.out.println("Bien");
        } else if (moyenne >= 10) {
            System.out.println("Passable");
        } else {
            System.out.println("Ajourne");
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Entrez le nombre de notes que vous saisir : ");
        int N = scanner.nextInt();
        int[] notes = new int[N];
        for (int i = 0; i < N; i++) {
            System.out.print("Note " + (i + 1) + " : ");
            notes[i] = scanner.nextInt();
        }
        calculerMoyenne(notes);
    }
}

class Main{


    void main(){
        Scanner scan = new Scanner(System.in);
    }
}